# IQ Funnel — Database Schema Design

This document details the minimal database design for the Japanese IQ Funnel backend.

It consolidates and modernizes the data model referenced in `dump-cellon_nexus_db-202608171321.sql`, eliminating legacy CMS tables, multi-site partitioning, and separate detail tables while preserving all core funnel capabilities.

---

## 1. Summary of Tables

| # | Table Name | Purpose | Key Notes |
|---|---|---|---|
| 1 | **`customers`** | Customer identity, login credentials, and Stripe customer mapping | Password hash for login; subscription details separated into dedicated table |
| 2 | **`customer_subscriptions`** | Tracks customer recurring subscriptions | Dedicated table for Stripe subscriptions, status, billing cycle, and cancellations |
| 3 | **`customer_quiz_results`** | Stores quiz attempts, calculated score, demographics, and attribution | Streamlined to essential fields (demographics, score, duration, report URLs) |
| 4 | **`customer_quiz_result_payment_transactions`** | Tracks all Stripe charges (first-sale, cross-sell/upsell, refunds) | Direct FK to quiz results, tracks native currency (JPY/GBP) + GBP normalized value |
| 5 | **`currency_rates`** | Exchange rates (e.g., JPY to GBP) | Simple key-value rate mapping for currency normalization and pricing |
| 6 | **`external_api_logs`** | Logs outgoing third-party API calls (Stripe, email service, webhooks) | Standardized request/response logging for audit and debugging |
| 7 | **`users`** | Internal admin users for backoffice / operations | Minimal administrative authentication & role table |

---

## 2. Entity-Relationship Diagram

```mermaid
erDiagram
    customers ||--o{ customer_quiz_results : "has many"
    customers ||--o{ customer_subscriptions : "has many"
    customers ||--o{ customer_quiz_result_payment_transactions : "pays"
    customer_quiz_results ||--o{ customer_quiz_result_payment_transactions : "has transactions"
    users
    currency_rates
    external_api_logs
```

---

## 3. Detailed Table Specifications

### 3.1 `customers`
Stores customer profile records, login credentials (`password_hash`), account `status`, and Stripe customer identifier.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `email` | `VARCHAR(255)` | No | | Unique customer email address |
| `password_hash` | `VARCHAR(255)` | Yes | `NULL` | Hashed password for customer account login |
| `email_verified` | `BOOLEAN` | No | `FALSE` | Set from the Reoon verification score when the email was captured |
| `status` | `VARCHAR(50)` | No | `'inactive'` | Account status: `inactive` (at quiz submit), `active` (post-verification/purchase) |
| `stripe_customer_id` | `VARCHAR(255)` | Yes | `NULL` | Stripe Customer ID (`cus_...`) |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Record creation timestamp |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Record update timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `UNIQUE (email)`
- `CREATE INDEX idx_customers_stripe_customer_id ON customers(stripe_customer_id);`

---

### 3.2 `customer_subscriptions` (Dedicated Subscriptions Table)
Stores recurring subscription records managed via Stripe.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `customer_id` | `BIGINT` | No | | Foreign key to `customers(id)` |
| `stripe_subscription_id` | `VARCHAR(255)` | No | | Stripe Subscription ID (`sub_...`) |
| `stripe_customer_id` | `VARCHAR(255)` | Yes | `NULL` | Stripe Customer ID (`cus_...`) |
| `status` | `VARCHAR(50)` | No | `'active'` | Status: `trialing`, `active`, `past_due`, `canceled`, `unpaid` |
| `plan_name` | `VARCHAR(100)` | Yes | `NULL` | Subscription plan name / identifier |
| `amount` | `NUMERIC(10, 2)` | No | | Subscription billing amount |
| `currency` | `VARCHAR(3)` | No | `'JPY'` | Currency code (`JPY` or `GBP`) |
| `current_period_start` | `TIMESTAMPTZ` | Yes | `NULL` | Start timestamp of current billing cycle |
| `current_period_end` | `TIMESTAMPTZ` | Yes | `NULL` | End timestamp of current billing cycle |
| `canceled_at` | `TIMESTAMPTZ` | Yes | `NULL` | Timestamp when subscription was canceled |
| `cancel_reason` | `VARCHAR(255)` | Yes | `NULL` | Reason recorded for cancellation |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Subscription record creation timestamp |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Record update timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `UNIQUE (stripe_subscription_id)`
- `FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE`
- `CREATE INDEX idx_subscriptions_customer_id ON customer_subscriptions(customer_id);`
- `CREATE INDEX idx_subscriptions_status ON customer_subscriptions(status);`

---

### 3.3 `customer_quiz_results`
Stores test attempts, demographic data, overall IQ score, 4 category scores, attribution, and generated report links.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `customer_id` | `BIGINT` | Yes | `NULL` | Foreign key to `customers(id)` |
| `email` | `VARCHAR(255)` | No | | Email provided by user upon test completion |
| `stripe_payment_method_id` | `VARCHAR(255)` | Yes | `NULL` | Card saved by the first sale, reused for the cross-sale and subscription |
| **Demographics** | | | | *(Used to personalize certificate and report)* |
| `first_name` | `VARCHAR(150)` | Yes | `NULL` | First name / given name (e.g. 太郎) |
| `last_name` | `VARCHAR(150)` | Yes | `NULL` | Last name / family name (e.g. 山田) |
| `age` | `VARCHAR(50)` | Yes | `NULL` | Age or age bracket (e.g., `25-34`) |
| `gender` | `VARCHAR(50)` | Yes | `NULL` | Gender (`male`, `female`, `other`, `prefer_not_to_say`) |
| **Scoring & Performance** | | | | |
| `iq_score` | `INTEGER` | Yes | `NULL` | Calculated overall IQ score (e.g., `128`) |
| `category_scores` | `JSONB` | Yes | `NULL` | 4 category scores (`logical`, `spatial`, `numerical`, `memory`) |
| `duration_seconds` | `INTEGER` | Yes | `NULL` | Total time taken to complete the quiz in seconds |
| **Funnel & Attribution** | | | | |
| `language` | `VARCHAR(10)` | No | `'ja'` | Test language: `'ja'` or `'en'` |
| `ip_address` | `VARCHAR(45)` | Yes | `NULL` | Client IP address |
| `country_code` | `VARCHAR(2)` | Yes | `'JP'` | Geo country code (e.g. `JP`, `US`) |
| `landing_url_details` | `JSONB` | Yes | `NULL` | Attribution JSON (`landing_url`, `utm_source`, `utm_medium`, `utm_campaign`, `referrer`) |
| **Generated Assets** | | | | |
| `report_urls` | `JSONB` | Yes | `NULL` | S3/Storage URLs (`certificate_url`, `report_pdf_url`, `career_report_url`) |
| **Timestamps** | | | | |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Submission timestamp |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Last update timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL`
- `CREATE INDEX idx_customer_quiz_results_email ON customer_quiz_results(email);`
- `CREATE INDEX idx_customer_quiz_results_customer_id ON customer_quiz_results(customer_id);`
- `CREATE INDEX idx_customer_quiz_results_created_at ON customer_quiz_results(created_at);`

---

### 3.4 `customer_quiz_result_payment_transactions`
Records every payment event (first sale, upsell/cross-sale, recurring renewal, refund) via Stripe.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `customer_quiz_result_id`| `BIGINT` | No | | Foreign key to `customer_quiz_results(id)` |
| `customer_id` | `BIGINT` | Yes | `NULL` | Foreign key to `customers(id)` |
| `transaction_type` | `VARCHAR(50)` | No | | Type: `first_sale`, `cross_sale`, `subscription`, `refund` |
| `amount` | `NUMERIC(10, 2)` | No | | Charge amount (e.g., `2980` for JPY, `19.99` for GBP) |
| `currency` | `VARCHAR(3)` | No | `'JPY'` | Currency code (`JPY` or `GBP`) |
| `amount_gbp` | `NUMERIC(15, 5)` | Yes | `NULL` | Normalized GBP equivalent for consolidated reporting. Five decimals: it is rate-derived, and rounding to pennies here would compound across aggregates. |
| `status` | `VARCHAR(50)` | No | `'pending'` | Status: `pending`, `succeeded`, `failed`, `refunded` |
| `stripe_payment_intent_id`| `VARCHAR(255)`| Yes | `NULL` | Stripe PaymentIntent ID (`pi_...`) |
| `stripe_charge_id` | `VARCHAR(255)` | Yes | `NULL` | Stripe Charge ID (`ch_...`) |
| `refunded_at` | `TIMESTAMPTZ` | Yes | `NULL` | Timestamp when refund was executed |
| `refund_amount` | `NUMERIC(10, 2)` | Yes | `NULL` | Amount refunded |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Transaction creation timestamp |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Transaction update timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `FOREIGN KEY (customer_quiz_result_id) REFERENCES customer_quiz_results(id) ON DELETE RESTRICT`
- `FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL`
- `CREATE INDEX idx_transactions_quiz_result_id ON customer_quiz_result_payment_transactions(customer_quiz_result_id);`
- `CREATE INDEX idx_transactions_stripe_pi ON customer_quiz_result_payment_transactions(stripe_payment_intent_id);`
- `CREATE INDEX idx_transactions_status ON customer_quiz_result_payment_transactions(status);`

---

### 3.5 `currency_rates`
Maintains latest exchange rates relative to GBP base currency.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `SERIAL` | No | | Primary key |
| `currency_code` | `VARCHAR(3)` | No | | Currency code (`JPY`, `GBP`, `USD`, ...) |
| `rate_to_gbp` | `NUMERIC(15, 6)`| No | | Units of this currency per 1 GBP (e.g., `216.800000` for JPY). GBP is the base and is always `1`. Refreshed every 12 hours from exchangeratesapi.io, which quotes in EUR and is rebased on GBP before storing. |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Timestamp when rate was last refreshed |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `UNIQUE (currency_code)`

---

### 3.6 `external_api_logs`
Logs outgoing/incoming external API requests (Stripe SDK calls, webhook events, email delivery API calls).

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `service_name` | `VARCHAR(100)`| No | | Target service (`stripe`, `sendgrid`, `resend`, `slack`) |
| `endpoint` | `VARCHAR(255)`| No | | API endpoint or action name (`/v1/payment_intents`, `send_email`) |
| `method` | `VARCHAR(10)` | No | | HTTP method (`POST`, `GET`, `PUT`, `DELETE`) |
| `status_code` | `INTEGER` | Yes | `NULL` | HTTP response status code (e.g. `200`, `400`, `500`) |
| `request_payload` | `JSONB` | Yes | `NULL` | Sanitized request parameters / payload |
| `response_payload`| `JSONB` | Yes | `NULL` | Response payload from external service |
| `is_error` | `BOOLEAN` | No | `FALSE` | Flag indicating if request failed or threw error |
| `error_message` | `TEXT` | Yes | `NULL` | Error details / message |
| `duration_ms` | `INTEGER` | Yes | `NULL` | Response latency in milliseconds |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Log creation timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `CREATE INDEX idx_external_api_logs_service ON external_api_logs(service_name, created_at);`
- `CREATE INDEX idx_external_api_logs_is_error ON external_api_logs(is_error);`

---

### 3.7 `users`
Internal admin users for administrative operations, refund processing, and reporting access.

| Column | Type | Nullable | Default | Description |
|---|---|---|---|---|
| `id` | `BIGSERIAL` | No | | Primary key |
| `name` | `VARCHAR(150)`| No | | Admin user full name |
| `email` | `VARCHAR(150)`| No | | Unique login email address |
| `password_hash` | `VARCHAR(255)`| No | | Argon2id / bcrypt hashed password |
| `role` | `VARCHAR(50)` | No | `'admin'` | Role: `admin`, `support`, `manager` |
| `status` | `VARCHAR(50)` | No | `'active'` | Status: `active`, `inactive` |
| `created_at` | `TIMESTAMPTZ` | No | `NOW()` | Creation timestamp |
| `updated_at` | `TIMESTAMPTZ` | No | `NOW()` | Last update timestamp |

**Indexes & Constraints**:
- `PRIMARY KEY (id)`
- `UNIQUE (email)`

---

## 4. Complete SQL DDL Script

```sql
-- =============================================================================
-- IQ Funnel - Minimalist Database Schema (PostgreSQL)
-- =============================================================================

-- 1. Currency Rates
CREATE TABLE IF NOT EXISTS currency_rates (
    id SERIAL PRIMARY KEY,
    currency_code VARCHAR(3) NOT NULL UNIQUE,
    rate_to_gbp NUMERIC(15, 6) NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed initial currency rates
INSERT INTO currency_rates (currency_code, rate_to_gbp, updated_at)
VALUES 
    ('GBP', 1.000000, NOW()),
    ('JPY', 216.800000, NOW()),
    ('USD', 1.362000, NOW())
ON CONFLICT (currency_code) DO NOTHING;

-- 2. Customers
CREATE TABLE IF NOT EXISTS customers (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    stripe_customer_id VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customers_stripe_customer_id ON customers(stripe_customer_id);

-- 3. Customer Subscriptions (Dedicated Table)
CREATE TABLE IF NOT EXISTS customer_subscriptions (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    customer_quiz_result_id BIGINT,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    stripe_customer_id VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    plan_name VARCHAR(100),
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'JPY',
    current_period_start TIMESTAMPTZ,
    current_period_end TIMESTAMPTZ,
    canceled_at TIMESTAMPTZ,
    cancel_reason VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_customer_id ON customer_subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON customer_subscriptions(status);

-- 4. Customer Quiz Results (Consolidated)
CREATE TABLE IF NOT EXISTS customer_quiz_results (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    email VARCHAR(255) NOT NULL,
    stripe_payment_method_id VARCHAR(255),
    
    -- Demographics
    first_name VARCHAR(150),
    last_name VARCHAR(150),
    age VARCHAR(50),
    gender VARCHAR(50),
    
    -- Scores & Performance
    iq_score INTEGER,
    duration_seconds INTEGER,
    
    -- Funnel & Marketing Attribution
    language VARCHAR(10) NOT NULL DEFAULT 'ja',
    ip_address VARCHAR(45),
    country_code VARCHAR(2) DEFAULT 'JP',
    landing_url_details JSONB,
    
    -- Assets
    report_urls JSONB,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_email ON customer_quiz_results(email);
CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_customer_id ON customer_quiz_results(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_created_at ON customer_quiz_results(created_at);

-- 5. Customer Quiz Result Payment Transactions
CREATE TABLE IF NOT EXISTS customer_quiz_result_payment_transactions (
    id BIGSERIAL PRIMARY KEY,
    customer_quiz_result_id BIGINT NOT NULL REFERENCES customer_quiz_results(id) ON DELETE RESTRICT,
    customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    
    transaction_type VARCHAR(50) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'JPY',
    amount_gbp NUMERIC(15, 5),
    
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    stripe_charge_id VARCHAR(255),
    
    refunded_at TIMESTAMPTZ,
    refund_amount NUMERIC(10, 2),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_quiz_result_id ON customer_quiz_result_payment_transactions(customer_quiz_result_id);
CREATE INDEX IF NOT EXISTS idx_transactions_stripe_pi ON customer_quiz_result_payment_transactions(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON customer_quiz_result_payment_transactions(status);

-- 6. External API Logs
CREATE TABLE IF NOT EXISTS external_api_logs (
    id BIGSERIAL PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    status_code INTEGER,
    request_payload JSONB,
    response_payload JSONB,
    is_error BOOLEAN NOT NULL DEFAULT FALSE,
    error_message TEXT,
    duration_ms INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_external_api_logs_service ON external_api_logs(service_name, created_at);
CREATE INDEX IF NOT EXISTS idx_external_api_logs_is_error ON external_api_logs(is_error);

-- 7. Users (Admin Users)
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'admin',
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
