-- =============================================================================
-- Second currency: USD -> GBP
-- =============================================================================
-- Run this against an existing database BEFORE starting the app on the new code.
--
-- Why before: DB_SYNCHRONIZE=true lets TypeORM reconcile the schema at boot, and
-- its idea of reconciling a renamed column is to DROP the old one and ADD an
-- empty new one. Renaming here keeps the historical figures; booting first
-- throws them away.
--
-- The stored values are rebased, not just relabelled. The old column held units
-- per 1 USD; the new one holds units per 1 GBP, and those are different numbers
-- for every currency. Each old rate is divided by the USD-per-GBP rate, which
-- the table itself supplies: rate_to_usd for 'GBP' is exactly that figure.
--
-- It also widens amount_gbp from numeric(10,2) to numeric(15,5). That figure is
-- rate-derived rather than charged, and pennies are the wrong resolution for a
-- number that exists to be summed. Note what this cannot do: a database where
-- an earlier run already rounded these to two decimals keeps the values it has
-- -- the discarded digits are not recoverable, only future writes gain them.
--
-- Safe to re-run: every step is guarded, and the rebase only touches rows the
-- rename just produced.
-- =============================================================================

BEGIN;

-- 1. currency_rates.rate_to_usd -> rate_to_gbp -------------------------------
DO $$
DECLARE
    usd_per_gbp NUMERIC(15, 6);
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'currency_rates' AND column_name = 'rate_to_usd'
    ) THEN
        -- Units of USD per 1 GBP, read before the rename while the column that
        -- holds it still has its old name. NULL when GBP was never synced --
        -- see the RAISE below.
        SELECT rate_to_usd INTO usd_per_gbp
        FROM currency_rates
        WHERE currency_code = 'GBP';

        ALTER TABLE currency_rates RENAME COLUMN rate_to_usd TO rate_to_gbp;

        IF usd_per_gbp IS NULL OR usd_per_gbp <= 0 THEN
            -- Nothing to rebase with. The rows are now mislabelled rather than
            -- wrong-and-silent, so fail loudly: run the sync (or the admin
            -- POST /admin/currency-rates/sync) and the whole table is rewritten
            -- from the provider anyway.
            RAISE WARNING 'No usable GBP rate stored — rate_to_gbp values are still USD-based. Run the currency sync before relying on them.';
        ELSE
            -- rate_to_usd was X per USD; X per GBP is that divided by USD-per-GBP.
            UPDATE currency_rates
            SET rate_to_gbp = ROUND(rate_to_gbp / usd_per_gbp, 6),
                updated_at = NOW()
            WHERE currency_code <> 'GBP';

            -- The base is 1 by definition, and USD is now an ordinary member of
            -- the set: 1 GBP buys usd_per_gbp dollars.
            UPDATE currency_rates SET rate_to_gbp = 1.000000, updated_at = NOW()
            WHERE currency_code = 'GBP';

            UPDATE currency_rates SET rate_to_gbp = usd_per_gbp, updated_at = NOW()
            WHERE currency_code = 'USD';

            -- A rate that no longer fits numeric(15,6) once rebased would have
            -- rounded to zero and become a divide-by-zero later on.
            DELETE FROM currency_rates WHERE rate_to_gbp <= 0;
        END IF;
    END IF;
END $$;

-- 2. transactions.amount_usd -> amount_gbp -----------------------------------
DO $$
DECLARE
    usd_per_gbp NUMERIC(15, 6);
    renamed BOOLEAN := FALSE;
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'customer_quiz_result_payment_transactions'
          AND column_name = 'amount_usd'
    ) THEN
        ALTER TABLE customer_quiz_result_payment_transactions
            RENAME COLUMN amount_usd TO amount_gbp;
        renamed := TRUE;
    END IF;

    -- Widen to five decimals, and do it BEFORE the rebase below: at the old
    -- numeric(10,2) the division result would be rounded straight back to
    -- pennies on assignment, which is the precision this widening exists to
    -- keep. Deliberately outside the rename guard so it also applies to a
    -- database where the rename has already been run. Guarded on the column
    -- rather than assumed, so this stays runnable against a database that has
    -- not built the table yet. Re-running is a no-op.
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'customer_quiz_result_payment_transactions'
          AND column_name = 'amount_gbp'
    ) THEN
        ALTER TABLE customer_quiz_result_payment_transactions
            ALTER COLUMN amount_gbp TYPE NUMERIC(15, 5);
    END IF;

    IF renamed THEN
        -- Post-rename, so this reads the rebased table from step 1: USD's row
        -- now holds dollars per 1 GBP.
        SELECT rate_to_gbp INTO usd_per_gbp
        FROM currency_rates WHERE currency_code = 'USD';

        IF usd_per_gbp IS NULL OR usd_per_gbp <= 0 THEN
            -- Converting with no rate would invent figures. Blanking them
            -- instead leaves the gap visible, and the payment service backfills
            -- a null amount_gbp on the next confirm once rates exist.
            RAISE WARNING 'No usable USD rate — historical amounts cleared for backfill.';
            UPDATE customer_quiz_result_payment_transactions
            SET amount_gbp = NULL
            WHERE amount_gbp IS NOT NULL;
        ELSE
            -- Five decimals, matching the widened column. The source figures
            -- were only ever stored to two, so this cannot manufacture
            -- precision that was never there — it just stops discarding more.
            UPDATE customer_quiz_result_payment_transactions
            SET amount_gbp = ROUND(amount_gbp / usd_per_gbp, 5)
            WHERE amount_gbp IS NOT NULL;
        END IF;
    END IF;
END $$;

COMMIT;

-- After this runs, refresh from the provider so every rate is a real GBP quote
-- rather than a locally-derived one:
--   POST /admin/currency-rates/sync
