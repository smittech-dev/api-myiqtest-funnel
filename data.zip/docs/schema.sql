-- =============================================================================
-- IQ Funnel - Minimalist Database Schema (PostgreSQL DDL)
-- Target: Minimal viable funnel for Japan (JPY / GBP, EN / JA)
-- =============================================================================

-- 1. Currency Rates
CREATE TABLE IF NOT EXISTS currency_rates (
    id SERIAL PRIMARY KEY,
    currency_code VARCHAR(3) NOT NULL UNIQUE,
    rate_to_gbp NUMERIC(15, 6) NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed initial currency rates
INSERT INTO currency_rates (currency_code, rate_to_gbp, updated_at)
VALUES 
    ('GBP', 1.000000, NOW()),
    ('JPY', 216.800000, NOW()),
    ('USD', 1.362000, NOW())
ON CONFLICT (currency_code) DO NOTHING;

-- 2. Customers
CREATE TABLE IF NOT EXISTS customers (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(50) NOT NULL DEFAULT 'inactive',
    stripe_customer_id VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customers_stripe_customer_id ON customers(stripe_customer_id);

-- 3. Customer Subscriptions (Dedicated Table)
CREATE TABLE IF NOT EXISTS customer_subscriptions (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    customer_quiz_result_id BIGINT,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    stripe_customer_id VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    plan_name VARCHAR(100),
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'JPY',
    current_period_start TIMESTAMPTZ,
    current_period_end TIMESTAMPTZ,
    canceled_at TIMESTAMPTZ,
    cancel_reason VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_customer_id ON customer_subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_quiz_result_id ON customer_subscriptions(customer_quiz_result_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON customer_subscriptions(status);

-- 4. Customer Quiz Results (Consolidated Attempt, Score, Demographics & Attribution)
CREATE TABLE IF NOT EXISTS customer_quiz_results (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    email VARCHAR(255) NOT NULL,
    stripe_payment_method_id VARCHAR(255),
    
    -- Demographics
    first_name VARCHAR(150),
    last_name VARCHAR(150),
    age VARCHAR(50),
    gender VARCHAR(50),
    
    -- Scores & Performance
    iq_score INTEGER,
    category_scores JSONB,
    duration_seconds INTEGER,
    
    -- Funnel & Marketing Attribution
    language VARCHAR(10) NOT NULL DEFAULT 'ja',
    ip_address VARCHAR(45),
    country_code VARCHAR(2) DEFAULT 'JP',
    landing_url_details JSONB,
    
    -- Assets
    report_urls JSONB,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_email ON customer_quiz_results(email);
CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_customer_id ON customer_quiz_results(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_quiz_results_created_at ON customer_quiz_results(created_at);

-- 5. Customer Quiz Result Payment Transactions
CREATE TABLE IF NOT EXISTS customer_quiz_result_payment_transactions (
    id BIGSERIAL PRIMARY KEY,
    customer_quiz_result_id BIGINT NOT NULL REFERENCES customer_quiz_results(id) ON DELETE RESTRICT,
    customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    
    transaction_type VARCHAR(50) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'JPY',
    amount_gbp NUMERIC(15, 5),
    
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    stripe_charge_id VARCHAR(255),
    
    refunded_at TIMESTAMPTZ,
    refund_amount NUMERIC(10, 2),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_quiz_result_id ON customer_quiz_result_payment_transactions(customer_quiz_result_id);
CREATE INDEX IF NOT EXISTS idx_transactions_stripe_pi ON customer_quiz_result_payment_transactions(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON customer_quiz_result_payment_transactions(status);

-- 6. External API Logs
CREATE TABLE IF NOT EXISTS external_api_logs (
    id BIGSERIAL PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    status_code INTEGER,
    request_payload JSONB,
    response_payload JSONB,
    is_error BOOLEAN NOT NULL DEFAULT FALSE,
    error_message TEXT,
    duration_ms INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_external_api_logs_service ON external_api_logs(service_name, created_at);
CREATE INDEX IF NOT EXISTS idx_external_api_logs_is_error ON external_api_logs(is_error);

-- 7. Users (Admin Users)
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'admin',
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. Email Marketing Logs
-- One row per (customer, sequence step). The UNIQUE constraint is the
-- guarantee that a customer never receives the same step twice: the runner
-- claims a step by inserting this row with ON CONFLICT DO NOTHING before it
-- calls the email provider, so duplicates are rejected by the database rather
-- than by a check that could race two cron ticks against each other.
CREATE TABLE IF NOT EXISTS email_marketing_logs (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    customer_quiz_result_id BIGINT,
    email VARCHAR(255) NOT NULL,

    -- Matches email_marketing_steps.step_key. Deliberately NOT a foreign key:
    -- deleting a retired step must neither erase the history of what it sent
    -- nor be blocked by that history.
    step_key VARCHAR(50) NOT NULL,
    -- Matches a template id in src/emails/registry.ts
    template_id VARCHAR(100) NOT NULL,
    discount_code VARCHAR(50),
    language VARCHAR(10) NOT NULL DEFAULT 'ja',

    -- pending | sent | failed | skipped
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    provider_message_id VARCHAR(255),
    error_message TEXT,
    skip_reason VARCHAR(255),
    attempts INTEGER NOT NULL DEFAULT 0,

    sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_email_marketing_logs_customer_step UNIQUE (customer_id, step_key)
);

CREATE INDEX IF NOT EXISTS idx_email_marketing_logs_customer_id ON email_marketing_logs(customer_id);
CREATE INDEX IF NOT EXISTS idx_email_marketing_logs_step_key ON email_marketing_logs(step_key);
CREATE INDEX IF NOT EXISTS idx_email_marketing_logs_status ON email_marketing_logs(status);
CREATE INDEX IF NOT EXISTS idx_email_marketing_logs_created_at ON email_marketing_logs(created_at);

-- 9. Email Marketing Settings
-- A deliberate singleton: always exactly one row, id = 1. The fixed primary key
-- makes the seed an INSERT ... ON CONFLICT DO NOTHING that two app instances
-- booting at once cannot duplicate.
CREATE TABLE IF NOT EXISTS email_marketing_settings (
    id INT PRIMARY KEY,

    -- The sequence's own switch, flipped from the admin panel. Separate from
    -- EMAIL_MARKETING_ENABLED, which decides whether the cron is registered.
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    -- Emails per run — caps the blast radius of a misconfiguration
    batch_size INT NOT NULL DEFAULT 50,
    -- Provider calls per step before it is abandoned as failed
    max_attempts INT NOT NULL DEFAULT 3,
    -- Quizzes older than this are never contacted; stops enabling the feature
    -- from emailing every unconverted lead in the table's history
    max_age_hours DOUBLE PRECISION NOT NULL DEFAULT 240,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Email Marketing Steps
-- One row per rung of the discount ladder. `step_key` is what
-- email_marketing_logs records, and therefore what the "already sent?"
-- guarantee is keyed on — see the note on that table.
CREATE TABLE IF NOT EXISTS email_marketing_steps (
    id BIGSERIAL PRIMARY KEY,
    step_key VARCHAR(50) NOT NULL UNIQUE,
    label VARCHAR(120) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    -- Fractional values allowed, so the ladder can be tested in minutes
    delay_hours DOUBLE PRECISION NOT NULL,
    -- A code from data/discount-codes.json; NULL means no discount
    discount_code VARCHAR(50),
    -- A template id from the master registry in src/emails/registry.ts
    template_id VARCHAR(100) NOT NULL,
    -- Display order only; the runner orders the ladder by delay_hours
    sort_order INT NOT NULL DEFAULT 0,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_marketing_steps_step_key ON email_marketing_steps(step_key);

-- Seed the sequence from the brief: 24h and 48h at 20% off, 72h and 5 days at
-- 50%. Disabled, so a fresh environment has a working ladder that sends nothing
-- until someone switches it on. The application seeds this itself on first boot
-- too — these statements only matter when building the schema by hand.
INSERT INTO email_marketing_settings (id, enabled, batch_size, max_attempts, max_age_hours)
VALUES (1, FALSE, 50, 3, 240)
ON CONFLICT (id) DO NOTHING;

INSERT INTO email_marketing_steps (step_key, label, enabled, delay_hours, discount_code, template_id, sort_order)
VALUES
    ('step_24h', '24 hours — 20% off', TRUE, 24,  'K75QSQC', 'marketing_reminder_day1', 0),
    ('step_48h', '48 hours — 20% off', TRUE, 48,  'K75QSQC', 'marketing_reminder_day2', 1),
    ('step_72h', '72 hours — 50% off', TRUE, 72,  '5G4A2TC', 'marketing_reminder_day3', 2),
    ('step_5d',  '5 days — 50% off',   TRUE, 120, '5G4A2TC', 'marketing_reminder_day5', 3)
ON CONFLICT (step_key) DO NOTHING;

-- 11. Email Transactional Logs
-- Delivery record for the two emails a paying customer receives: the welcome
-- with their brain-training credentials, and the report-ready notice.
--
-- Separate from email_marketing_logs because the two dedupe on different
-- things. A marketing step is once per PERSON (three quizzes, one 24-hour
-- nudge); a transactional email is once per PURCHASE (a customer who returns
-- and buys again has bought a second report and must be sent it). `dedup_key`
-- carries that scope explicitly — 'welcome:1042', 'report_ready:1042' — and is
-- UNIQUE, claimed by an insert before the provider is called, so the Stripe
-- webhook and the confirm endpoint racing on one payment cannot double-send.
CREATE TABLE IF NOT EXISTS email_transactional_logs (
    id BIGSERIAL PRIMARY KEY,
    dedup_key VARCHAR(120) NOT NULL UNIQUE,

    customer_id BIGINT,
    customer_quiz_result_id BIGINT,
    email VARCHAR(255) NOT NULL,

    -- A template id from the master registry in src/emails/registry.ts
    template_id VARCHAR(100) NOT NULL,
    language VARCHAR(10) NOT NULL DEFAULT 'ja',

    -- pending | sent | failed
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    provider_message_id VARCHAR(255),
    error_message TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,

    sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_transactional_logs_dedup_key ON email_transactional_logs(dedup_key);
CREATE INDEX IF NOT EXISTS idx_email_transactional_logs_customer_id ON email_transactional_logs(customer_id);
CREATE INDEX IF NOT EXISTS idx_email_transactional_logs_status ON email_transactional_logs(status);
CREATE INDEX IF NOT EXISTS idx_email_transactional_logs_created_at ON email_transactional_logs(created_at);

-- The welcome email issues the customer's brain-training password. This column
-- records that it happened: customers.password_hash is seeded with a throwaway
-- sha256 value at quiz submission, so a non-null hash proves nothing, and
-- without this a returning customer's second purchase would silently reset the
-- password they are already using.
ALTER TABLE customers ADD COLUMN IF NOT EXISTS password_set_at TIMESTAMPTZ;
