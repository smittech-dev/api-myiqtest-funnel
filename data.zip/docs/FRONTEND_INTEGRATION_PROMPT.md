# Frontend Funnel — Backend Integration Prompt

> **How to use this document:** paste it as the task prompt for the frontend funnel repo. It
> describes every API the funnel needs, exactly where in the existing UI flow to call it, and what
> to keep in session. Every request/response example below was captured from the running backend —
> they are real payloads, not illustrations.

---

## 0. Ground rules

1. **Do not change any existing UI, layout, copy, images, or styling.** The static funnel flow is
   already approved. Your job is to replace hardcoded values with API data and wire up the
   navigation logic — nothing else.
2. **The only content that becomes dynamic is price.** Every other piece of text stays exactly as it
   is. Where a price appears in copy (headings, bullets, buttons, order summaries, comparison
   tables), swap the hardcoded number for the value from the price API. Do not reword the sentence
   around it.
3. **One price fetch per funnel session.** Fetch prices once when the funnel starts, store them in
   session, and read from session everywhere. Do not re-fetch per page — the price the customer was
   shown on the landing page must be the price they are charged at checkout.
4. **Never compute prices on the frontend.** No multiplying, no applying discounts client-side for
   display. The API returns both the original and the discounted price; render what it gives you.
5. **The backend is the source of truth for navigation on the four post-quiz pages only** —
   checkout, cross-sell, customer details, and result. For those, the page the customer belongs on
   comes from `redirect_url`, with exactly one frontend-side override (cross-sell skip — see §7).
   The landing page and the quiz itself are **not** guarded and keep their existing navigation:
   there is no funnel session to check until the quiz has been submitted.

---

## 1. Environment & authentication

| Item | Value |
|---|---|
| Base URL | `{{API_BASE_URL}}` — put this in an env var, e.g. `NEXT_PUBLIC_API_BASE_URL` |
| Auth header | `x-api-key: {{API_KEY}}` — required on **every** funnel endpoint |
| Content type | `application/json` |

The API key is only required when the backend has `API_KEY` set. Ask the backend team for the value
per environment.

> **Note on the API key:** anything shipped to the browser is readable by the customer — this key is
> a basic gate, not a secret. Do not treat it as a security boundary. If your framework supports
> server-side route handlers (Next.js Route Handlers / server actions), proxying these calls through
> your own server and keeping the key server-side is preferable.

**Stripe publishable key** is also needed on the frontend: `{{STRIPE_PUBLISHABLE_KEY}}` (`pk_test_…`
in staging, `pk_live_…` in production).

---

## 2. Response envelope

Every endpoint returns the same wrapper. **Always read `data`, never the root object.**

**Success**
```json
{
  "success": true,
  "data": { },
  "message": "optional human-readable string"
}
```

**Error**
```json
{
  "success": false,
  "error": {
    "message": "Validation failed",
    "details": [
      { "field": "email", "message": "Invalid email" },
      { "field": "iq_score", "message": "Number must be less than or equal to 200" }
    ]
  }
}
```

`error.details` is present only for validation failures (HTTP 400). Build a single shared API client
that:

- attaches the `x-api-key` header,
- parses the envelope and throws on `success: false` or non-2xx,
- surfaces `error.message` (plus `error.details` when present) to the caller.

**Status codes you must handle**

| Code | Meaning | Frontend behaviour |
|---|---|---|
| `200` / `201` | OK | proceed |
| `400` | Validation failed, or a disallowed discount | show a field/inline error; do not retry blindly |
| `401` / `403` | Missing / wrong `x-api-key` | fatal config error — log it loudly |
| `404` | `quiz_id` not found | session is stale → clear it and restart the funnel |
| `409` | Already paid, or the funnel step is out of order | re-check `/questions/results` and route to `redirect_url` |
| `502` | Stripe or another provider unreachable | show a retry affordance; the payment may still be fine — re-check results |

---

## 3. Session model

Persist these for the whole funnel session (`sessionStorage` is a good fit; use `localStorage` if
you need survival across tab closes). Nothing here is sensitive.

| Key | Set when | Used by |
|---|---|---|
| `landing_url_details` | first page load of the funnel | quiz submit (§8) |
| `language` | funnel start (`ja` \| `en`) | price, quiz submit, payment |
| `price_dis` | funnel start, if the campaign carries a discount code | price **and** create-payment-intent |
| `pricing` | after the price call | every price render in the UI |
| `quiz_id` | after quiz submit | every downstream call |
| `cross_sell_skipped` | when the customer skips the upsell | redirect override (§7) |

> **`quiz_id` is the funnel's primary key.** It is an encrypted string. Store it verbatim, never
> parse or modify it, and send it exactly as received. Every step after quiz submit needs it. If it
> is lost, the customer cannot continue and must restart.

---

## 4. Landing page — capture attribution

**When:** on the very first funnel page load, before anything else. Capture once and do not
overwrite on later page views (otherwise internal navigation destroys the original attribution).

Build a `landing_url_details` object and store it in session **only if one is not already stored**.

| Field | Source |
|---|---|
| `landing_url` | the full current URL, including query string |
| `utm_source` | `utm_source` query parameter |
| `utm_medium` | `utm_medium` query parameter |
| `utm_campaign` | `utm_campaign` query parameter |
| `referrer` | the document referrer |

All five fields are optional and each must be a string when present. **Omit keys you do not have**
rather than sending `null` or an empty string. This object is sent later with the quiz submit (§8) —
there is no separate endpoint for it.

Also capture at this point, from the URL or your campaign config:

- `language` — `ja` or `en`
- `price_dis` — the discount **code** for this campaign, if any (see §5.1)

---

## 5. Price API

### `GET /price`

Fetch **once** at funnel start, right after the landing capture. Store the result in session and
render from it everywhere.

**Query parameters**

| Param | Required | Notes |
|---|---|---|
| `language` | no (default `ja`) | `ja` or `en`. `lang` is accepted as an alias. Anything else falls back to `ja`. |
| `price_dis` | no | Discount **code** for the **first sale** — a string, never a percentage. Must be one the backend has configured. May be personalised (see §5.1). Anything unrecognised returns `400`. |

**Request**
```
GET {{API_BASE_URL}}/price?language=ja&price_dis=K75QSQC
x-api-key: {{API_KEY}}
```

**Response `200`**
```json
{
  "success": true,
  "data": {
    "language": "ja",
    "currency": "JPY",
    "discount_percentage": 20,
    "discount_code": "K75QSQC",
    "first_sale": {
      "title": "公式IQ認定証＋詳細診断レポート",
      "currency": "JPY",
      "original_price": 2980,
      "price": 2384,
      "discount_percentage": 20,
      "stripe_amount": 2384
    },
    "cross_sale": {
      "title": "プレミアム適職・キャリア分析レポート",
      "currency": "JPY",
      "original_price": 1480,
      "price": 1480,
      "discount_percentage": 0,
      "stripe_amount": 1480
    },
    "subscription": {
      "title": "IQ脳力トレーニング月額プラン",
      "currency": "JPY",
      "original_price": 980,
      "price": 980,
      "discount_percentage": 0,
      "stripe_amount": 980,
      "price_id": "price_1U7…"
    }
  }
}
```

**Field meanings**

| Field | Use |
|---|---|
| `original_price` | The list price. Render as the struck-through "was" price **only when `discount_percentage > 0`**. |
| `price` | What the customer actually pays. **This is the number to show everywhere.** |
| `discount_percentage` | `0` when no discount applies. Drive "X% OFF" badges from this. |
| `discount_code` | The canonical code that matched (e.g. `K75QSQC`), or `null`. Use it to confirm the campaign code was accepted. |
| `stripe_amount` | Smallest currency unit (JPY 2384 = ¥2,384; GBP 1999 = £19.99). **Only** for Stripe Elements setup (§6). Never display it. |
| `currency` | `JPY` or `GBP` — use for formatting (`Intl.NumberFormat`). |
| `subscription.price_id` | Informational. The frontend never sends this anywhere. |

### 5.1 Discount codes — read carefully

**The frontend sends a code, never a percentage.** Codes map to percentages only in backend config,
so the client cannot influence how large a discount is.

**Codes are random 6–7 character alphanumeric strings** such as `K75QSQC` — there is no pattern to
derive and no relationship between the code and the percentage it grants. They are configured
server-side in `data/discount-codes.json` and can be rotated at any time.

> **Do not hardcode discount codes in frontend source.** They arrive with the campaign (URL
> parameter, campaign config, or CMS) and are shipped to the browser only for the customer who was
> given one. Never ship the full list.

**Personalised codes.** You may prefix a code with the **first two letters of the customer's email
plus an underscore** — for example `pu_K75QSQC` for `purchaser@example.com`, or `ha_K75QSQC` for
`harness@example.com`. The backend strips that three-character prefix and resolves the remaining
code, so both forms give the identical result. Use whichever the campaign requires; if you have no
reason to personalise, send the plain code.

Matching is **case-insensitive** and surrounding whitespace is ignored, so `k75qsqc`, `K75QSQC`, and
`pu_k75qsqc` all resolve to `K75QSQC`. The response echoes the canonical code back in
`discount_code` — compare against it if you need to confirm which campaign applied.

Other rules:

- The discount applies to the **first sale only**. `cross_sale` and `subscription` always come back
  at list price with `discount_percentage: 0`, because their endpoints charge list price. Do not
  render a discount on them.
- **Whatever `price_dis` you used for `/price`, you must send the identical value to
  `create-payment-intent`** (§6.3). If they differ, the customer is shown one price and charged
  another. Read it from session in both places.
- The backend re-resolves the code when creating the payment intent. An unrecognised code is
  rejected with `400` there too, so a tampered client cannot buy at an arbitrary discount.
- If there is no campaign discount, **omit `price_dis` entirely** (do not send an empty string).
- An unrecognised code returns `400` from `/price`. Decide with the business what should happen —
  falling back to full price is usually right; failing the page is not.

### 5.2 Where prices appear

Sweep the funnel for hardcoded amounts and replace each with the session value. Typically:

- landing page pricing/offer sections
- checkout page order summary and the pay button label
- cross-sell offer page
- any comparison table, bullet list, or footnote quoting a figure

Keep the surrounding copy, currency symbol placement, and formatting exactly as designed.

---

## 6. Checkout — first sale

### 6.1 Payment methods required

| Method | Stripe component |
|---|---|
| Card | **Payment Element** (`elements.create('payment')`) |
| Apple Pay / Google Pay | **Express Checkout Element** (`elements.create('expressCheckout')`) |

Both mount from the **same `elements` group** and both drive the same backend calls. Place the
Express Checkout Element above the card form (Stripe's recommended layout) without altering the
approved design.

> **Apple Pay prerequisites:** the domain must be registered in the Stripe Dashboard
> (Settings → Payments → Payment methods → Apple Pay → Add domain) and the page must be served over
> HTTPS. Apple Pay will silently not render otherwise. Google Pay needs no registration. The Express
> Checkout Element renders nothing when the browser supports neither — make sure the card form still
> looks correct in that case.

### 6.2 Creating the Elements group — deferred intent flow

**Do not create the PaymentIntent when the checkout page loads.** The backend creates the customer,
the PaymentIntent and the transaction row at that moment, so calling it on page load produces junk
records for people who never pay. Mount the form first; create the intent when the customer actually
pays.

Create a single Stripe Elements group configured from the session pricing, then mount both
components onto it:

| Elements option | Value |
|---|---|
| `mode` | `'payment'` |
| `amount` | `pricing.first_sale.stripe_amount` — the smallest currency unit |
| `currency` | `pricing.first_sale.currency`, lowercased (`jpy` / `gbp`) |
| `setupFutureUsage` | `'off_session'` |
| `appearance` | whatever matches the approved design |

Then:

1. Create the **Payment Element** with the billing address country set to `never`, and mount it into
   the existing card container.
2. Create the **Express Checkout Element** and mount it into its own container above the card form.

> **These options must match the PaymentIntent the backend creates, or Stripe rejects the
> confirmation.** The backend sets `setup_future_usage: 'off_session'` (so the card can be reused
> for the cross-sell and the subscription without asking again) and uses the discounted amount.
> Getting `amount`, `currency`, or `setupFutureUsage` wrong produces errors like
> *"The provided setup_future_usage (off_session) does not match the expected setup_future_usage
> (null)"*.

Hiding the billing country (`country: 'never'`) is deliberate — the design has no country field.
Because it is hidden, **you must supply the country yourself at confirm time** (§6.4).

### 6.3 On pay — create the PaymentIntent

### `POST /payment/first-sale/create-payment-intent`

Called from the card "Pay" click **and** from the Express Checkout `confirm` event.

**Request**
```json
{
  "quiz_id": "MjI5OTZkNWU5NWFhOTg1Y2Rh…",
  "language": "ja",
  "price_dis": "K75QSQC"
}
```

| Field | Required | Notes |
|---|---|---|
| `quiz_id` | yes | from session |
| `language` | no | falls back to the language saved with the quiz |
| `price_dis` | no | The discount **code**, string. **Must equal** the value used for `/price`; omit when there is no discount |

**Response `200`**
```json
{
  "success": true,
  "data": {
    "client_secret": "pi_3U7sCY…_secret_VweNi0…",
    "payment_intent_id": "pi_3U7sCYPztQ12W7w12uPEt0lW",
    "amount": 2384,
    "original_amount": 2980,
    "discount_percentage": 20,
    "discount_code": "K75QSQC",
    "currency": "JPY"
  },
  "message": "First sale payment intent created successfully"
}
```

**Notes**

- Calling this twice (retry after a decline, refresh) **reuses** the same pending PaymentIntent —
  it will not double-charge or create duplicate records. Safe to retry.
- If the first sale is already paid it returns `409`
  (`"The first sale has already been paid for this quiz"`). Treat this as "already done": call
  `/questions/results` and route to the returned `redirect_url`.
- `amount` here is authoritative. If it differs from what the UI is showing, the session price is
  stale — re-render from this response before confirming.

### 6.4 Confirm with Stripe

**Card path** — on the pay button click, in order:

1. Call `elements.submit()` to validate the form. If it returns an error, show it and stop.
2. Call `POST /payment/first-sale/create-payment-intent` (§6.3) with `quiz_id`, `language`, and the
   `price_dis` **code** from session — omit `price_dis` when there is no discount.
3. Call `stripe.confirmPayment()` with:
   - `elements` — the group from §6.2
   - `clientSecret` — from the response in step 2
   - `confirmParams.return_url` — an absolute URL to your completion route
   - `confirmParams.payment_method_data.billing_details.address.country` — `JP` for `ja`, `US` for
     `en` (required because the country field is hidden)
   - `redirect: 'if_required'`
4. If it returns an error, show it and stop. If `paymentIntent.status` is not `succeeded`, treat it
   as a failure.
5. Call the settle endpoint (§6.5) with the `payment_intent_id` from step 2.

**Express Checkout path (Apple Pay / Google Pay)** — the same sequence, triggered from the element's
`confirm` event instead of a button click. The only difference is step 3: wallets supply their own
billing details, so **do not** send `payment_method_data.billing_details`. `return_url` and
`redirect: 'if_required'` are still required.

> **`return_url` is mandatory** even with `redirect: 'if_required'`, because the intent enables
> automatic payment methods and Stripe cannot rule out a redirect-based method up front. Omitting it
> throws *"the `confirmParams.return_url` argument is required when using automatic payment
> methods."* With `redirect: 'if_required'`, cards (including inline 3-D Secure) complete without
> leaving the page; the URL is only used if a redirect method is chosen.

Build a completion route (for example `/checkout/complete`) that reads the `payment_intent` query
parameter and runs the settle step in §6.5, so redirect-based methods finish correctly.

### 6.5 Settle the payment — do not wait for the webhook

### `POST /payment/first-sale/payments/confirm`

Call this **immediately** after Stripe reports success. It re-reads the PaymentIntent from Stripe
(your claim is not trusted), settles the transaction, activates the customer, starts the
subscription, and returns where to go next. Stripe's webhook does the same thing but can lag by
seconds — the funnel must not stall waiting for it.

**Request**
```json
{
  "quiz_id": "MjI5OTZkNWU5NWFhOTg1Y2Rh…",
  "payment_intent_id": "pi_3U7sCpPztQ12W7w10HDAg2Y8"
}
```

**Response `200`**
```json
{
  "success": true,
  "data": {
    "status": "succeeded",
    "payment_intent_id": "pi_3U7sCpPztQ12W7w10HDAg2Y8",
    "paid": true,
    "requires_action": false,
    "client_secret": "pi_3U7sCp…_secret_LyG9DY…",
    "amount": 2384,
    "currency": "JPY",
    "redirect_url": "CROSS_SELL_PAGE",
    "subscription": {
      "created": true,
      "subscription_id": "sub_1U7sCsPztQ12W7w1mwd0DLbe",
      "status": "active",
      "reason": null
    }
  },
  "message": "First sale payment confirmation processed"
}
```

- **A `200` does not mean paid.** Check `paid: true` before advancing.
- Navigate using `redirect_url` (§7).
- `subscription` is informational — the subscription starts automatically on the same card. Do not
  build UI around it unless the design already has some; `created: false` with a `reason` is not an
  error the customer should ever see.
- Safe to call more than once; a repeat returns the same settled state.

---

## 7. Redirect logic

**Scope: this applies to the checkout, cross-sell, customer details, and result pages only.** The
landing page and the quiz are not guarded — there is no funnel session to check until the quiz has
been submitted, so leave their existing navigation untouched.

Every response that can change funnel state returns `redirect_url`. `GET /questions/results` returns
it on demand.

### `GET /questions/results`

**Request**
```
GET {{API_BASE_URL}}/questions/results?quiz_id=MjI5OTZkNWU5NWFhOTg1Y2Rh…
x-api-key: {{API_KEY}}
```

**Response `200`**
```json
{
  "success": true,
  "data": {
    "redirect_url": "CHECKOUT_PAGE",
    "quiz": {
      "quiz_id": "ZjY0ZWM2MWUwMzMxYWJlNDNjZGE2Njk4…",
      "iq_score": 128,
      "category_scores": null,
      "language": "ja",
      "duration_seconds": null
    },
    "customer": {
      "email": "customer@example.com",
      "first_name": null,
      "last_name": null,
      "age": null
    }
  }
}
```

> `quiz.quiz_id` is re-encrypted on every call, so **the string differs each time**. This is normal.
> Keep using the `quiz_id` you already have in session; do not overwrite it and do not compare them
> for equality.

### Routing table

| `redirect_url` | Route to |
|---|---|
| `CHECKOUT_PAGE` | checkout / first sale |
| `CROSS_SELL_PAGE` | cross-sell offer |
| `CUSTOMER_DETAILS_PAGE` | customer details form |
| `THANK_YOU_PAGE` | thank you / result page |

**Call it as a guard** on entry to each of the four post-quiz pages — checkout, cross-sell, customer
details, and result. If the returned value does not match the page the customer is on, redirect them
to the right one. This makes refreshes, back buttons, and shared links behave correctly on those
pages. Do not add this guard to the landing page or the quiz.

### 7.1 The one frontend override — cross-sell skip

The backend has no concept of "declined the upsell": it only knows whether the cross-sale was paid.
So a customer who skips it keeps getting `CROSS_SELL_PAGE`. Handle this in the frontend:

Apply a single rule wherever you consume a `redirect_url`: **if the value is `CROSS_SELL_PAGE` and
`cross_sell_skipped` is set in session, treat it as `CUSTOMER_DETAILS_PAGE` instead.** Every other
value passes through unchanged.

- Set `cross_sell_skipped = true` in session the moment the customer clicks the skip/decline control,
  **before** navigating.
- Apply this rule to **every** `redirect_url` you act on — from the guard call and from both payment
  confirm responses.
- Only ever skip *forward*. Never use this to send someone backwards.
- Once the customer saves their details, the backend returns `THANK_YOU_PAGE` on its own and the
  override stops mattering.

---

## 8. Quiz submit

### `POST /questions/submit`

**When:** the moment the quiz is finished and the email captured — this is what creates the funnel
session server-side.

**Request**
```json
{
  "email": "customer@example.com",
  "iq_score": 128,
  "category_scores": { "logical": 32, "spatial": 28, "numerical": 30, "memory": 25 },
  "duration_seconds": 640,
  "language": "ja",
  "landing_url_details": {
    "landing_url": "https://example.com/lp/a",
    "utm_source": "google",
    "utm_medium": "cpc",
    "utm_campaign": "jp_iq_2026",
    "referrer": "https://referrer.example.com/"
  }
}
```

| Field | Required | Rules |
|---|---|---|
| `email` | **yes** | must be a valid email |
| `iq_score` | **yes** | integer, `40`–`200`. Calculated by the frontend. |
| `category_scores` | no | object with `logical`, `spatial`, `numerical`, `memory` (numbers) |
| `duration_seconds` | no | non-negative integer |
| `language` | no | `ja` or `en`; anything else is treated as `ja` |
| `landing_url_details` | no | the object captured in §4 — send it verbatim from session |

**Response `201`**
```json
{
  "success": true,
  "data": { "quiz_id": "MjI5OTZkNWU5NWFhOTg1Y2RhNWVlMzcwNjZiZGQ3ZTU6MWRjYTllOTFlYzg0MDk4NjA2M2U2ZGVj…" },
  "message": "Quiz submitted successfully"
}
```

**Store `data.quiz_id` in session immediately** — everything downstream depends on it.

The backend also runs email verification here (an external provider), which can add a few hundred
milliseconds. Show your existing loading state; do not add a timeout shorter than ~10s.

---

## 9. Cross-sell

There is **no payment form on this page**. The card saved during the first sale is charged directly,
so the customer only has to accept.

### `POST /payment/cross-sale/confirm`

**Request**
```json
{ "quiz_id": "MjI5OTZkNWU5NWFhOTg1Y2Rh…", "language": "ja" }
```

**Response `200`**
```json
{
  "success": true,
  "data": {
    "status": "succeeded",
    "payment_intent_id": "pi_3U7sCvPztQ12W7w125d3NoeV",
    "paid": true,
    "requires_action": false,
    "client_secret": "pi_3U7sCv…_secret_fFlUhP…",
    "amount": 1480,
    "currency": "JPY",
    "redirect_url": "CUSTOMER_DETAILS_PAGE"
  },
  "message": "Cross-sale payment processed"
}
```

**Accept button** → call the endpoint → on `paid: true`, route via `redirect_url`.

**Skip button** → set `cross_sell_skipped = true` in session → go to the customer details page. No
API call.

**Edge cases**

| Situation | Response | Handling |
|---|---|---|
| Saved card needs authentication | `200` with `requires_action: true`, `paid: false` | Rare. The customer must re-authenticate — show a friendly failure and let them continue to the details page. Do not silently retry. |
| Card declined | `400` | Show the message; offer skip so they are not trapped. |
| First sale not completed | `409` | Session is out of order — re-run the guard and route to `redirect_url`. |
| Called twice | `200`, same `payment_intent_id` | Idempotent — no double charge. |

---

## 10. Customer details

### `PUT /customer/update`

**Request**
```json
{
  "quiz_id": "MjI5OTZkNWU5NWFhOTg1Y2Rh…",
  "first_name": "太郎",
  "last_name": "山田",
  "age": "30"
}
```

All four fields are **required** and non-empty. **`age` is a string, not a number** — send `"30"`,
not `30`.

**Response `200`**
```json
{
  "success": true,
  "data": { "updated": true },
  "message": "Customer details updated successfully"
}
```

After this succeeds, go to the thank-you page. Saving details also makes the backend return
`THANK_YOU_PAGE` from then on, even if the cross-sell was skipped.

---

## 11. Thank-you page

Call `GET /questions/results` (§7) and render from `data.quiz` and `data.customer`:
`iq_score`, `category_scores`, `language`, `first_name`, `last_name`, `age`, `email`.

Keep the existing layout and copy; only fill in the values.

---

## 12. End-to-end sequence

```
Landing page
  ├─ capture landing_url_details, language, price_dis (code) → session
  └─ GET /price?language=&price_dis=                   → session.pricing → render all prices

Quiz
  └─ POST /questions/submit  { email, iq_score, …, landing_url_details }
        → session.quiz_id
        → route by redirect_url (CHECKOUT_PAGE)

Checkout                                    [guard: GET /questions/results]
  ├─ mount Payment Element + Express Checkout Element (deferred, no intent yet)
  ├─ on pay: elements.submit()
  ├─ POST /payment/first-sale/create-payment-intent { quiz_id, language, price_dis }
  ├─ stripe.confirmPayment({ elements, clientSecret, return_url, redirect:'if_required' })
  └─ POST /payment/first-sale/payments/confirm { quiz_id, payment_intent_id }
        → route by redirect_url (CROSS_SELL_PAGE)

Cross-sell                                  [guard: GET /questions/results]
  ├─ Accept → POST /payment/cross-sale/confirm { quiz_id, language }
  │            → route by redirect_url (CUSTOMER_DETAILS_PAGE)
  └─ Skip   → session.cross_sell_skipped = true → CUSTOMER_DETAILS_PAGE

Customer details                            [guard: GET /questions/results + skip override]
  └─ PUT /customer/update { quiz_id, first_name, last_name, age }
        → THANK_YOU_PAGE

Thank you                                   [guard: GET /questions/results]
  └─ GET /questions/results → render score + customer
```

---

## 13. Endpoint quick reference

| # | Method | Path | Body / Query | Returns |
|---|---|---|---|---|
| 1 | `GET` | `/price` | `?language=ja&price_dis=K75QSQC` | three prices, discounted first sale |
| 2 | `POST` | `/questions/submit` | `{ email, iq_score, category_scores?, duration_seconds?, language?, landing_url_details? }` | `{ quiz_id }` |
| 3 | `GET` | `/questions/results` | `?quiz_id=…` | `{ redirect_url, quiz, customer }` |
| 4 | `POST` | `/payment/first-sale/create-payment-intent` | `{ quiz_id, language?, price_dis? }` | `{ client_secret, payment_intent_id, amount, original_amount, discount_percentage, discount_code, currency }` |
| 5 | `POST` | `/payment/first-sale/payments/confirm` | `{ quiz_id, payment_intent_id }` | `{ paid, redirect_url, subscription, … }` |
| 6 | `POST` | `/payment/cross-sale/confirm` | `{ quiz_id, language? }` | `{ paid, redirect_url, … }` |
| 7 | `PUT` | `/customer/update` | `{ quiz_id, first_name, last_name, age }` | `{ updated: true }` |

`POST /payment/webhook` exists but is **called by Stripe only** — the frontend never touches it.

Interactive docs (Swagger UI) are served by the backend at `{{API_BASE_URL}}/docs`, with the raw
OpenAPI spec at `{{API_BASE_URL}}/docs.json` for generating a typed client.

---

## 14. Acceptance checklist

**Pricing**
- [ ] No hardcoded prices remain anywhere in the funnel
- [ ] `/price` is called once per session; all pages read from session
- [ ] `original_price` renders struck-through **only** when `discount_percentage > 0`
- [ ] The same `price_dis` **code** goes to `/price` and to `create-payment-intent`
- [ ] Discount codes are sent as strings; the frontend never sends or derives a percentage
- [ ] Personalised codes (`xx_CODE`) work identically to plain ones
- [ ] Cross-sell and subscription are never shown as discounted
- [ ] No copy, layout, or styling changed — only the numbers

**Session & attribution**
- [ ] `landing_url_details` captured on first load and not overwritten
- [ ] UTM params and `document.referrer` included when present
- [ ] `quiz_id` stored verbatim and sent on every downstream call

**Payments**
- [ ] Nothing is created server-side until the customer clicks pay
- [ ] `elements()` `amount`, `currency`, `setupFutureUsage: 'off_session'` match the intent
- [ ] `return_url` present in `confirmParams`
- [ ] Card pays via Payment Element; Apple Pay / Google Pay via Express Checkout Element
- [ ] Apple Pay domain registered in Stripe; page served over HTTPS
- [ ] `first-sale/payments/confirm` called immediately after Stripe succeeds
- [ ] Card declines show an inline error and allow retry (retrying is safe)

**Navigation**
- [ ] Checkout, cross-sell, customer details and result each guard on `GET /questions/results`
- [ ] The landing page and quiz are **not** guarded and keep their existing navigation
- [ ] Navigation always follows `redirect_url`
- [ ] Skipping the cross-sell sets `cross_sell_skipped` and moves forward to the details form
- [ ] The skip override is applied to every `redirect_url` consumed
- [ ] Refresh / back button / re-opened link all land on the correct page

**Test cards** (test mode): `4242 4242 4242 4242` succeeds · `4000 0025 0000 3155` triggers 3-D
Secure · any future expiry and any CVC.
