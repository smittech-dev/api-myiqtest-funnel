--
-- PostgreSQL database dump
--

\restrict WgWELJsiem2png8vYS2U259pFHZzE3EFWa71mmPidGdqzfZQiCE2pRehHrBXZdZ

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.6

-- Started on 2026-08-17 13:21:21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 8 (class 2615 OID 17532)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 8378 (class 0 OID 0)
-- Dependencies: 8
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 2 (class 3079 OID 1183614)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 8379 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 4432 (class 1247 OID 17534)
-- Name: enum_quiz_result_payment_transactions_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_quiz_result_payment_transactions_status AS ENUM (
    'pending',
    'success',
    'failed',
    'refunded',
    'trial',
    'cancelled',
    'on_hold',
    'expired',
    'pending_cancel',
    'refund_initiated'
);


--
-- TOC entry 4435 (class 1247 OID 17554)
-- Name: enum_quiz_result_payment_transactions_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_quiz_result_payment_transactions_type AS ENUM (
    'first_sale',
    'cross_sale',
    'subscription',
    'renewal',
    'refund',
    'first_sale_first_split',
    'first_sale_second_split',
    'trial'
);


--
-- TOC entry 4438 (class 1247 OID 17570)
-- Name: enum_quizzes_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_quizzes_status AS ENUM (
    'active',
    'inactive'
);


--
-- TOC entry 4441 (class 1247 OID 17576)
-- Name: enum_users_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_users_gender AS ENUM (
    'male',
    'female',
    'other'
);


--
-- TOC entry 4444 (class 1247 OID 17584)
-- Name: enum_users_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_users_status AS ENUM (
    'active',
    'inactive'
);


--
-- TOC entry 3767 (class 1255 OID 17589)
-- Name: copy_pricing_master_rules_for_new_site(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.copy_pricing_master_rules_for_new_site(IN source_site_id integer, IN new_site_id integer)
    LANGUAGE plpgsql
    AS $$
      BEGIN

          INSERT INTO pricing_master_rules (
              site_id, is_subsite, currency_code, first_sale_price, cross_sale_price, subscription_price, payment_gateways, free_access_enabled, cross_sale_compulsory, subscription_after, show_cross_sale_page, iq_booster_validity, first_split_percentage, second_split_percentage, pricing_discount, created_by, updated_by, created_at, updated_at
          )
          SELECT
              new_site_id, is_subsite, currency_code, first_sale_price, cross_sale_price, subscription_price, payment_gateways, free_access_enabled, cross_sale_compulsory, subscription_after, show_cross_sale_page, iq_booster_validity, first_split_percentage, second_split_percentage, pricing_discount, created_by, updated_by, created_at, updated_at
          FROM pricing_master_rules
          WHERE site_id = source_site_id;

      END;
      $$;


--
-- TOC entry 3775 (class 1255 OID 142071)
-- Name: copy_questions_for_new_site(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.copy_questions_for_new_site(IN source_site_id integer, IN new_site_id integer)
    LANGUAGE plpgsql
    AS $$
      DECLARE
          v_new_q_id INT;
          rec_q RECORD;
      BEGIN

          FOR rec_q IN 
              SELECT id, quiz_id, site_id, category_id, name, question_type_id, image_url, is_excluded, created_by, updated_by, created_at, updated_at, deleted_at, parent_id, is_negative, is_excluded_from_variation, is_ab_testing, tag
              FROM questions 
              WHERE site_id = source_site_id 
          LOOP
              INSERT INTO questions (quiz_id, site_id, category_id, name, question_type_id, image_url, is_excluded, created_by, updated_by, created_at, updated_at, deleted_at, parent_id, is_negative, is_excluded_from_variation, is_ab_testing, tag)
		          VALUES (rec_q.quiz_id, new_site_id, rec_q.category_id, rec_q.name, rec_q.question_type_id, rec_q.image_url, rec_q.is_excluded, rec_q.created_by, rec_q.updated_by, rec_q.created_at, rec_q.updated_at, rec_q.deleted_at, COALESCE(rec_q.parent_id, rec_q.id), rec_q.is_negative, rec_q.is_excluded_from_variation, rec_q.is_ab_testing, rec_q.tag)
              RETURNING id INTO v_new_q_id;

              INSERT INTO question_options (question_id, text, image_url, score_value, is_correct, display_order, rating_left_label, rating_right_label, rating_count, weight)
              SELECT v_new_q_id, text, image_url, score_value, is_correct, display_order, rating_left_label, rating_right_label, rating_count, weight
              FROM question_options
              WHERE question_id = rec_q.id;

              INSERT INTO question_orders (quiz_id, site_id, question_id, display_order, created_by, updated_by, created_at, updated_at)
              SELECT quiz_id, new_site_id, v_new_q_id, display_order, created_by, updated_by, created_at, updated_at
              FROM question_orders
              WHERE question_id = rec_q.id AND site_id = source_site_id;
          END LOOP;
          
      END;
      $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 3654 (class 1259 OID 17591)
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


--
-- TOC entry 3728 (class 1259 OID 906152)
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id bigint NOT NULL,
    trace_id uuid,
    channel character varying(255) NOT NULL,
    event character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'info'::character varying NOT NULL,
    gateway character varying(255),
    description text,
    site_id integer,
    customer_id integer,
    quiz_result_id bigint,
    transaction_id bigint,
    subject_type character varying(255),
    subject_id bigint,
    properties jsonb,
    error_message text,
    duration_ms integer,
    source character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3727 (class 1259 OID 906151)
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8380 (class 0 OID 0)
-- Dependencies: 3727
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- TOC entry 3716 (class 1259 OID 234787)
-- Name: aws_server_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_server_logs (
    id bigint NOT NULL,
    type character varying(255),
    data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3715 (class 1259 OID 234786)
-- Name: aws_server_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aws_server_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8381 (class 0 OID 0)
-- Dependencies: 3715
-- Name: aws_server_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aws_server_logs_id_seq OWNED BY public.aws_server_logs.id;


--
-- TOC entry 3655 (class 1259 OID 17604)
-- Name: billing_platforms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_platforms (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    credentials jsonb,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone
);


--
-- TOC entry 3656 (class 1259 OID 17614)
-- Name: billing_platforms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_platforms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8382 (class 0 OID 0)
-- Dependencies: 3656
-- Name: billing_platforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_platforms_id_seq OWNED BY public.billing_platforms.id;


--
-- TOC entry 3710 (class 1259 OID 155347)
-- Name: cancel_subscription_email_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cancel_subscription_email_otps (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    otp_code character varying(10) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    verified_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


--
-- TOC entry 3709 (class 1259 OID 155346)
-- Name: cancel_subscription_email_otps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cancel_subscription_email_otps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8383 (class 0 OID 0)
-- Dependencies: 3709
-- Name: cancel_subscription_email_otps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cancel_subscription_email_otps_id_seq OWNED BY public.cancel_subscription_email_otps.id;


--
-- TOC entry 3657 (class 1259 OID 17615)
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    key character varying(255),
    question_type_id jsonb
);


--
-- TOC entry 3658 (class 1259 OID 17624)
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8384 (class 0 OID 0)
-- Dependencies: 3658
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- TOC entry 3659 (class 1259 OID 17625)
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    code character(2) NOT NULL,
    name character varying(50) NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 3660 (class 1259 OID 17632)
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currencies (
    code character(3) NOT NULL,
    name character varying(50),
    symbol character varying(10),
    default_locale character varying(10),
    is_active boolean DEFAULT true
);


--
-- TOC entry 3661 (class 1259 OID 17637)
-- Name: currency_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currency_rates (
    id bigint NOT NULL,
    currency_code character(3) NOT NULL,
    rate numeric(15,6) NOT NULL,
    updated_date timestamp without time zone NOT NULL
);


--
-- TOC entry 8385 (class 0 OID 0)
-- Dependencies: 3661
-- Name: COLUMN currency_rates.rate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currency_rates.rate IS 'Exchange rate to USD (1 USD = rate * currency_code)';


--
-- TOC entry 8386 (class 0 OID 0)
-- Dependencies: 3661
-- Name: COLUMN currency_rates.updated_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currency_rates.updated_date IS 'Date when the rate was last updated';


--
-- TOC entry 3662 (class 1259 OID 17644)
-- Name: currency_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.currency_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8387 (class 0 OID 0)
-- Dependencies: 3662
-- Name: currency_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.currency_rates_id_seq OWNED BY public.currency_rates.id;


--
-- TOC entry 3663 (class 1259 OID 17645)
-- Name: customer_quiz_result_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_quiz_result_details (
    id bigint NOT NULL,
    customer_quiz_result_id bigint NOT NULL,
    payment_verified_manually boolean DEFAULT false NOT NULL,
    generate_report_manually boolean DEFAULT false NOT NULL,
    iq_score character varying(255),
    duration integer,
    best_category_id bigint,
    billing_platform_email_delivered_details json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    landing_url_detail jsonb,
    google_analytics_triggered boolean DEFAULT false,
    variant_type character varying(255),
    is_iq_booster_subscription_migrated boolean DEFAULT false,
    is_subscription_generated boolean,
    utm_sources text
);


--
-- TOC entry 3664 (class 1259 OID 17658)
-- Name: customer_quiz_result_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_quiz_result_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8388 (class 0 OID 0)
-- Dependencies: 3664
-- Name: customer_quiz_result_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_quiz_result_details_id_seq OWNED BY public.customer_quiz_result_details.id;


--
-- TOC entry 3718 (class 1259 OID 235031)
-- Name: customer_quiz_result_json_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_quiz_result_json_details (
    id bigint NOT NULL,
    customer_quiz_result_id bigint CONSTRAINT customer_quiz_result_json_deta_customer_quiz_result_id_not_null NOT NULL,
    result_json jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 3717 (class 1259 OID 235030)
-- Name: customer_quiz_result_json_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_quiz_result_json_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8389 (class 0 OID 0)
-- Dependencies: 3717
-- Name: customer_quiz_result_json_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_quiz_result_json_details_id_seq OWNED BY public.customer_quiz_result_json_details.id;


--
-- TOC entry 3665 (class 1259 OID 17659)
-- Name: customer_quiz_result_payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_quiz_result_payment_transactions (
    id integer NOT NULL,
    customer_quiz_result_id integer CONSTRAINT customer_quiz_result_payment_t_customer_quiz_result_id_not_null NOT NULL,
    payment_provider_id bigint,
    type public.enum_quiz_result_payment_transactions_type NOT NULL,
    amount numeric(10,2) NOT NULL,
    card_last_4_digit character varying(4),
    card_type character varying(20),
    status public.enum_quiz_result_payment_transactions_status NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    charge_id character varying(255),
    payment_method_id text,
    currency_code character(3),
    refunded_at timestamp without time zone,
    refunded_by bigint,
    refunded_charge_id character varying(100),
    refunded_description character varying(255),
    paypal_customer_email character varying(255),
    paypal_order_id character varying(255),
    refund_initiated_at timestamp without time zone,
    amount_usd numeric(10,2),
    failed_reason character varying(255),
    invoice_id character varying(255),
    bin_number character varying(255)
);


--
-- TOC entry 3666 (class 1259 OID 17671)
-- Name: customer_quiz_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_quiz_results (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    quiz_id integer NOT NULL,
    result_json_file_url character varying(255),
    certificate_file_url jsonb,
    report_file_url jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    ip_address character varying(100),
    country_code character(2),
    sub_type character varying(100),
    old_quiz_result_id bigint,
    redirect_page character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    age character varying(255),
    gender character varying(255)
);


--
-- TOC entry 3667 (class 1259 OID 17682)
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    site_id integer NOT NULL,
    email character varying(255),
    billing_platform_user_id character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email_score integer,
    subscription_id character varying(255),
    payment_gateway_customer_id character varying(255),
    subscription_cancelled_at timestamp without time zone,
    subscription_cancelled_by bigint,
    deleted_at timestamp without time zone,
    deleted_by bigint,
    deleted_description character varying(255),
    billing_platform_login_details json,
    subscription_cancelled_reason character varying(255),
    billing_platform_deleted_at timestamp without time zone,
    billing_platform_deleted_by integer,
    getresponse_deleted_at timestamp without time zone,
    getresponse_deleted_by bigint,
    payment_gateway_subscription_id character varying(255),
    payment_gateway_customer_ids jsonb,
    subscription_status character varying(255),
    subscription_status_updated_at timestamp without time zone,
    billing_platform_password character varying(255),
    subscription_created_at timestamp without time zone
);


--
-- TOC entry 3720 (class 1259 OID 409928)
-- Name: email_send_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_send_logs (
    id bigint NOT NULL,
    customer_quiz_result_id bigint NOT NULL,
    request_id character varying(255),
    email_log jsonb,
    status character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 3719 (class 1259 OID 409927)
-- Name: email_send_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_send_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8390 (class 0 OID 0)
-- Dependencies: 3719
-- Name: email_send_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_send_logs_id_seq OWNED BY public.email_send_logs.id;


--
-- TOC entry 3704 (class 1259 OID 18307)
-- Name: external_api_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_api_logs (
    id integer NOT NULL,
    billing_platform_id bigint,
    site_id bigint,
    key_id bigint,
    data json,
    response_body jsonb,
    type character varying(255),
    status character varying(255),
    platform_name character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_gateway_error boolean DEFAULT false NOT NULL,
    retry_count integer
);


--
-- TOC entry 3703 (class 1259 OID 18306)
-- Name: external_api_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.external_api_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8391 (class 0 OID 0)
-- Dependencies: 3703
-- Name: external_api_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.external_api_logs_id_seq OWNED BY public.external_api_logs.id;


--
-- TOC entry 3724 (class 1259 OID 701727)
-- Name: failed_invoice_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_invoice_details (
    id bigint NOT NULL,
    invoice_id character varying(255) NOT NULL,
    charge_id character varying(255),
    quiz_data_id bigint,
    bin_number character varying(255),
    attempt_count character varying(255),
    next_payment_attempt character varying(255),
    finalized_at character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(255),
    mark_uncollectible_at timestamp without time zone
);


--
-- TOC entry 3723 (class 1259 OID 701726)
-- Name: failed_invoice_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_invoice_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8392 (class 0 OID 0)
-- Dependencies: 3723
-- Name: failed_invoice_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_invoice_details_id_seq OWNED BY public.failed_invoice_details.id;


--
-- TOC entry 3668 (class 1259 OID 17691)
-- Name: generic_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.generic_settings (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    smtp_details json,
    payment_text json,
    sandbox_user_details json,
    sandbox_site_payment_providers json,
    production_site_payment_providers json,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by bigint,
    subscription_details jsonb,
    email_templates json,
    pdf_templates json,
    analytics_details json,
    promocode_metadata json,
    getresponse_api_details json
);


--
-- TOC entry 8393 (class 0 OID 0)
-- Dependencies: 3668
-- Name: COLUMN generic_settings.analytics_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.generic_settings.analytics_details IS 'Google Analytics configuration: {"measurement_id": "G-XXXXXXXXXX", "api_secret": "secret"}';


--
-- TOC entry 3669 (class 1259 OID 17702)
-- Name: generic_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.generic_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8394 (class 0 OID 0)
-- Dependencies: 3669
-- Name: generic_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.generic_settings_id_seq OWNED BY public.generic_settings.id;


--
-- TOC entry 3670 (class 1259 OID 17703)
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 3706 (class 1259 OID 94537)
-- Name: modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modules (
    id bigint NOT NULL,
    name character varying(255),
    slug character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 3705 (class 1259 OID 94536)
-- Name: modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8395 (class 0 OID 0)
-- Dependencies: 3705
-- Name: modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modules_id_seq OWNED BY public.modules.id;


--
-- TOC entry 3671 (class 1259 OID 17710)
-- Name: payment_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_providers (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    api_base_url character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- TOC entry 3672 (class 1259 OID 17720)
-- Name: payment_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8396 (class 0 OID 0)
-- Dependencies: 3672
-- Name: payment_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_providers_id_seq OWNED BY public.payment_providers.id;


--
-- TOC entry 3673 (class 1259 OID 17721)
-- Name: pricing_country_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_country_rules (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    is_main_site boolean DEFAULT false NOT NULL,
    country_code character(2) NOT NULL,
    currency_code character(3) NOT NULL,
    first_sale_price numeric(10,2),
    cross_sale_price numeric(10,2),
    subscription_price numeric(10,2),
    payment_gateways jsonb,
    free_access_enabled boolean DEFAULT false NOT NULL,
    cross_sale_compulsory boolean DEFAULT false NOT NULL,
    subscription_after smallint,
    show_cross_sale_page boolean DEFAULT true NOT NULL,
    iq_booster_validity smallint,
    first_split_percentage smallint,
    second_split_percentage smallint,
    prc_id jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    other_subscription_detail jsonb
);


--
-- TOC entry 3674 (class 1259 OID 17742)
-- Name: pricing_country_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pricing_country_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8397 (class 0 OID 0)
-- Dependencies: 3674
-- Name: pricing_country_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pricing_country_rules_id_seq OWNED BY public.pricing_country_rules.id;


--
-- TOC entry 3675 (class 1259 OID 17743)
-- Name: pricing_master_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_master_rules (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    is_subsite boolean DEFAULT false NOT NULL,
    currency_code character(3) NOT NULL,
    first_sale_price numeric(10,2),
    cross_sale_price numeric(10,2),
    subscription_price numeric(10,2),
    payment_gateways jsonb,
    free_access_enabled boolean DEFAULT false NOT NULL,
    cross_sale_compulsory boolean DEFAULT false NOT NULL,
    subscription_after smallint,
    show_cross_sale_page boolean DEFAULT true NOT NULL,
    iq_booster_validity smallint,
    first_split_percentage smallint,
    second_split_percentage smallint,
    pricing_discount jsonb,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    ab_testing_pricing jsonb,
    other_subscription_detail jsonb
);


--
-- TOC entry 3676 (class 1259 OID 17761)
-- Name: pricing_master_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pricing_master_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8398 (class 0 OID 0)
-- Dependencies: 3676
-- Name: pricing_master_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pricing_master_rules_id_seq OWNED BY public.pricing_master_rules.id;


--
-- TOC entry 3677 (class 1259 OID 17762)
-- Name: promocode_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promocode_usage (
    id integer NOT NULL,
    promocode_id integer NOT NULL,
    used_for_quiz_result_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 3678 (class 1259 OID 17770)
-- Name: promocode_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.promocode_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8399 (class 0 OID 0)
-- Dependencies: 3678
-- Name: promocode_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.promocode_usage_id_seq OWNED BY public.promocode_usage.id;


--
-- TOC entry 3679 (class 1259 OID 17771)
-- Name: promocodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promocodes (
    id integer NOT NULL,
    site_id bigint,
    code character varying(50) NOT NULL,
    type smallint,
    value smallint,
    occurrence smallint DEFAULT 1,
    is_active boolean DEFAULT true,
    generated_from_quiz_result_id integer,
    created_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    domain character varying(100)
);


--
-- TOC entry 8400 (class 0 OID 0)
-- Dependencies: 3679
-- Name: COLUMN promocodes.occurrence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.promocodes.occurrence IS '0 means unlimited';


--
-- TOC entry 3680 (class 1259 OID 17780)
-- Name: promocodes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.promocodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8401 (class 0 OID 0)
-- Dependencies: 3680
-- Name: promocodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.promocodes_id_seq OWNED BY public.promocodes.id;


--
-- TOC entry 3681 (class 1259 OID 17781)
-- Name: question_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.question_options (
    id bigint NOT NULL,
    question_id bigint NOT NULL,
    text text,
    image_url text,
    score_value integer,
    is_correct boolean,
    display_order integer,
    rating_left_label character varying(255),
    rating_right_label character varying(255),
    rating_count integer,
    weight integer
);


--
-- TOC entry 3682 (class 1259 OID 17788)
-- Name: question_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.question_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8402 (class 0 OID 0)
-- Dependencies: 3682
-- Name: question_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.question_options_id_seq OWNED BY public.question_options.id;


--
-- TOC entry 3683 (class 1259 OID 17789)
-- Name: question_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.question_orders (
    id bigint NOT NULL,
    quiz_id bigint,
    site_id bigint,
    question_id bigint,
    display_order integer,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- TOC entry 3684 (class 1259 OID 17794)
-- Name: question_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.question_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8403 (class 0 OID 0)
-- Dependencies: 3684
-- Name: question_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.question_orders_id_seq OWNED BY public.question_orders.id;


--
-- TOC entry 3685 (class 1259 OID 17795)
-- Name: question_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.question_types (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- TOC entry 3686 (class 1259 OID 17807)
-- Name: question_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.question_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8404 (class 0 OID 0)
-- Dependencies: 3686
-- Name: question_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.question_types_id_seq OWNED BY public.question_types.id;


--
-- TOC entry 3687 (class 1259 OID 17808)
-- Name: questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.questions (
    id bigint NOT NULL,
    quiz_id bigint,
    site_id bigint,
    category_id bigint,
    name text,
    question_type_id integer,
    image_url text,
    is_excluded boolean DEFAULT false,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    parent_id integer,
    is_negative boolean DEFAULT false NOT NULL,
    is_excluded_from_variation boolean DEFAULT false NOT NULL,
    is_ab_testing boolean DEFAULT false NOT NULL,
    tag jsonb
);


--
-- TOC entry 3688 (class 1259 OID 17818)
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.questions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8405 (class 0 OID 0)
-- Dependencies: 3688
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- TOC entry 3689 (class 1259 OID 17819)
-- Name: quiz_public_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quiz_public_cache (
    id bigint NOT NULL,
    quiz_id bigint,
    site_id bigint,
    payload_json json,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    variant_type character varying(255),
    tag jsonb
);


--
-- TOC entry 3690 (class 1259 OID 17826)
-- Name: quiz_public_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quiz_public_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8406 (class 0 OID 0)
-- Dependencies: 3690
-- Name: quiz_public_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quiz_public_cache_id_seq OWNED BY public.quiz_public_cache.id;


--
-- TOC entry 3731 (class 1259 OID 1172351)
-- Name: quiz_question_report_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quiz_question_report_data (
    id bigint NOT NULL,
    site_id bigint,
    question_no integer,
    question_id bigint NOT NULL,
    question_text character varying(255),
    parent_question_text character varying(255),
    total_users bigint DEFAULT 0 NOT NULL,
    attempted bigint DEFAULT 0 NOT NULL,
    correct bigint DEFAULT 0 NOT NULL,
    wrong bigint DEFAULT 0 NOT NULL,
    skipped bigint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3730 (class 1259 OID 1172350)
-- Name: quiz_question_report_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quiz_question_report_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8407 (class 0 OID 0)
-- Dependencies: 3730
-- Name: quiz_question_report_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quiz_question_report_data_id_seq OWNED BY public.quiz_question_report_data.id;


--
-- TOC entry 3691 (class 1259 OID 17827)
-- Name: quiz_result_payment_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quiz_result_payment_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8408 (class 0 OID 0)
-- Dependencies: 3691
-- Name: quiz_result_payment_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quiz_result_payment_transactions_id_seq OWNED BY public.customer_quiz_result_payment_transactions.id;


--
-- TOC entry 3729 (class 1259 OID 1172333)
-- Name: quiz_result_question_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quiz_result_question_data (
    customer_quiz_result_id bigint NOT NULL,
    result_json_file_url text,
    status character varying(20) DEFAULT 'pending'::character varying,
    quiz_data jsonb,
    skipped_question_ids jsonb,
    served_count integer,
    attempted_count integer,
    correct_count integer,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3692 (class 1259 OID 17828)
-- Name: quiz_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quiz_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8409 (class 0 OID 0)
-- Dependencies: 3692
-- Name: quiz_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quiz_results_id_seq OWNED BY public.customer_quiz_results.id;


--
-- TOC entry 3693 (class 1259 OID 17829)
-- Name: quizzes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quizzes (
    id bigint NOT NULL,
    site_id bigint,
    name character varying(255) NOT NULL,
    status public.enum_quizzes_status DEFAULT 'active'::public.enum_quizzes_status NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- TOC entry 3694 (class 1259 OID 17839)
-- Name: quizzes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quizzes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8410 (class 0 OID 0)
-- Dependencies: 3694
-- Name: quizzes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quizzes_id_seq OWNED BY public.quizzes.id;


--
-- TOC entry 3722 (class 1259 OID 469828)
-- Name: report_service_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_service_metrics (
    id bigint NOT NULL,
    site_id bigint,
    report_date date,
    sales integer DEFAULT 0,
    income numeric(18,4) DEFAULT 0,
    refund numeric(18,4) DEFAULT 0,
    spent numeric(18,4) DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 3721 (class 1259 OID 469827)
-- Name: report_service_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_service_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8411 (class 0 OID 0)
-- Dependencies: 3721
-- Name: report_service_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_service_metrics_id_seq OWNED BY public.report_service_metrics.id;


--
-- TOC entry 3708 (class 1259 OID 94549)
-- Name: role_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_modules (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    module_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 3707 (class 1259 OID 94548)
-- Name: role_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8412 (class 0 OID 0)
-- Dependencies: 3707
-- Name: role_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_modules_id_seq OWNED BY public.role_modules.id;


--
-- TOC entry 3695 (class 1259 OID 17840)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone
);


--
-- TOC entry 3696 (class 1259 OID 17847)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8413 (class 0 OID 0)
-- Dependencies: 3696
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 3726 (class 1259 OID 793728)
-- Name: site_transaction_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_transaction_metrics (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    date date NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    quiz_submissions integer DEFAULT 0,
    paid_quiz_submissions integer DEFAULT 0,
    subscriptions_created integer DEFAULT 0,
    subscriptions_renewed integer DEFAULT 0,
    subscriptions_renewal_failed integer DEFAULT 0,
    stripe_transactions_success integer DEFAULT 0,
    stripe_transactions_failed integer DEFAULT 0,
    refunds integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 3725 (class 1259 OID 793727)
-- Name: site_transaction_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_transaction_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8414 (class 0 OID 0)
-- Dependencies: 3725
-- Name: site_transaction_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_transaction_metrics_id_seq OWNED BY public.site_transaction_metrics.id;


--
-- TOC entry 3697 (class 1259 OID 17848)
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id bigint NOT NULL,
    parent_id bigint,
    name character varying(255),
    host character varying(255) NOT NULL,
    billing_platform_id bigint,
    key character varying(255),
    secret character varying(255),
    is_active boolean DEFAULT true,
    category_id jsonb,
    language_code character varying(255),
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    slug character varying(255),
    quiz_result_type character varying(255)
);


--
-- TOC entry 3698 (class 1259 OID 17858)
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8415 (class 0 OID 0)
-- Dependencies: 3698
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- TOC entry 3714 (class 1259 OID 208751)
-- Name: stripe_migration_error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stripe_migration_error_logs (
    id bigint NOT NULL,
    nexus_quiz_data_id bigint NOT NULL,
    quiz_data_id bigint NOT NULL,
    user_id bigint,
    subscription_id bigint,
    request_data json,
    error_data json,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3713 (class 1259 OID 208750)
-- Name: stripe_migration_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stripe_migration_error_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8416 (class 0 OID 0)
-- Dependencies: 3713
-- Name: stripe_migration_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stripe_migration_error_logs_id_seq OWNED BY public.stripe_migration_error_logs.id;


--
-- TOC entry 3699 (class 1259 OID 17860)
-- Name: token_blacklist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_blacklist (
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3712 (class 1259 OID 155364)
-- Name: trustpilot_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trustpilot_tokens (
    id bigint NOT NULL,
    refresh_token character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3711 (class 1259 OID 155363)
-- Name: trustpilot_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trustpilot_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8417 (class 0 OID 0)
-- Dependencies: 3711
-- Name: trustpilot_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trustpilot_tokens_id_seq OWNED BY public.trustpilot_tokens.id;


--
-- TOC entry 3700 (class 1259 OID 17871)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    password character varying(255) NOT NULL,
    role_id bigint NOT NULL,
    assign_site jsonb,
    status public.enum_users_status DEFAULT 'active'::public.enum_users_status NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    is_google2fa_enable boolean DEFAULT false NOT NULL,
    google2fa_secret character varying(255)
);


--
-- TOC entry 3701 (class 1259 OID 17886)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8418 (class 0 OID 0)
-- Dependencies: 3701
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3702 (class 1259 OID 17887)
-- Name: users_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 8419 (class 0 OID 0)
-- Dependencies: 3702
-- Name: users_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq1 OWNED BY public.customers.id;


--
-- TOC entry 7959 (class 2604 OID 906155)
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- TOC entry 7935 (class 2604 OID 234790)
-- Name: aws_server_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_server_logs ALTER COLUMN id SET DEFAULT nextval('public.aws_server_logs_id_seq'::regclass);


--
-- TOC entry 7860 (class 2604 OID 17889)
-- Name: billing_platforms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_platforms ALTER COLUMN id SET DEFAULT nextval('public.billing_platforms_id_seq'::regclass);


--
-- TOC entry 7928 (class 2604 OID 155350)
-- Name: cancel_subscription_email_otps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cancel_subscription_email_otps ALTER COLUMN id SET DEFAULT nextval('public.cancel_subscription_email_otps_id_seq'::regclass);


--
-- TOC entry 7862 (class 2604 OID 17890)
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- TOC entry 7866 (class 2604 OID 17891)
-- Name: currency_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currency_rates ALTER COLUMN id SET DEFAULT nextval('public.currency_rates_id_seq'::regclass);


--
-- TOC entry 7867 (class 2604 OID 17892)
-- Name: customer_quiz_result_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_details ALTER COLUMN id SET DEFAULT nextval('public.customer_quiz_result_details_id_seq'::regclass);


--
-- TOC entry 7938 (class 2604 OID 235034)
-- Name: customer_quiz_result_json_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_json_details ALTER COLUMN id SET DEFAULT nextval('public.customer_quiz_result_json_details_id_seq'::regclass);


--
-- TOC entry 7872 (class 2604 OID 17893)
-- Name: customer_quiz_result_payment_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_payment_transactions ALTER COLUMN id SET DEFAULT nextval('public.quiz_result_payment_transactions_id_seq'::regclass);


--
-- TOC entry 7873 (class 2604 OID 17894)
-- Name: customer_quiz_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_results ALTER COLUMN id SET DEFAULT nextval('public.quiz_results_id_seq'::regclass);


--
-- TOC entry 7874 (class 2604 OID 17895)
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq1'::regclass);


--
-- TOC entry 7939 (class 2604 OID 409931)
-- Name: email_send_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_send_logs ALTER COLUMN id SET DEFAULT nextval('public.email_send_logs_id_seq'::regclass);


--
-- TOC entry 7924 (class 2604 OID 18310)
-- Name: external_api_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_api_logs ALTER COLUMN id SET DEFAULT nextval('public.external_api_logs_id_seq'::regclass);


--
-- TOC entry 7945 (class 2604 OID 701730)
-- Name: failed_invoice_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_invoice_details ALTER COLUMN id SET DEFAULT nextval('public.failed_invoice_details_id_seq'::regclass);


--
-- TOC entry 7875 (class 2604 OID 17896)
-- Name: generic_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.generic_settings ALTER COLUMN id SET DEFAULT nextval('public.generic_settings_id_seq'::regclass);


--
-- TOC entry 7926 (class 2604 OID 94540)
-- Name: modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modules ALTER COLUMN id SET DEFAULT nextval('public.modules_id_seq'::regclass);


--
-- TOC entry 7879 (class 2604 OID 17897)
-- Name: payment_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_providers ALTER COLUMN id SET DEFAULT nextval('public.payment_providers_id_seq'::regclass);


--
-- TOC entry 7882 (class 2604 OID 17898)
-- Name: pricing_country_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules ALTER COLUMN id SET DEFAULT nextval('public.pricing_country_rules_id_seq'::regclass);


--
-- TOC entry 7888 (class 2604 OID 17899)
-- Name: pricing_master_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules ALTER COLUMN id SET DEFAULT nextval('public.pricing_master_rules_id_seq'::regclass);


--
-- TOC entry 7893 (class 2604 OID 17900)
-- Name: promocode_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocode_usage ALTER COLUMN id SET DEFAULT nextval('public.promocode_usage_id_seq'::regclass);


--
-- TOC entry 7894 (class 2604 OID 17901)
-- Name: promocodes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes ALTER COLUMN id SET DEFAULT nextval('public.promocodes_id_seq'::regclass);


--
-- TOC entry 7897 (class 2604 OID 17902)
-- Name: question_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_options ALTER COLUMN id SET DEFAULT nextval('public.question_options_id_seq'::regclass);


--
-- TOC entry 7898 (class 2604 OID 17903)
-- Name: question_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders ALTER COLUMN id SET DEFAULT nextval('public.question_orders_id_seq'::regclass);


--
-- TOC entry 7900 (class 2604 OID 17904)
-- Name: question_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_types ALTER COLUMN id SET DEFAULT nextval('public.question_types_id_seq'::regclass);


--
-- TOC entry 7902 (class 2604 OID 17905)
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- TOC entry 7908 (class 2604 OID 17906)
-- Name: quiz_public_cache id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_public_cache ALTER COLUMN id SET DEFAULT nextval('public.quiz_public_cache_id_seq'::regclass);


--
-- TOC entry 7966 (class 2604 OID 1172354)
-- Name: quiz_question_report_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_question_report_data ALTER COLUMN id SET DEFAULT nextval('public.quiz_question_report_data_id_seq'::regclass);


--
-- TOC entry 7910 (class 2604 OID 17907)
-- Name: quizzes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quizzes ALTER COLUMN id SET DEFAULT nextval('public.quizzes_id_seq'::regclass);


--
-- TOC entry 7940 (class 2604 OID 469831)
-- Name: report_service_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_service_metrics ALTER COLUMN id SET DEFAULT nextval('public.report_service_metrics_id_seq'::regclass);


--
-- TOC entry 7927 (class 2604 OID 94552)
-- Name: role_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_modules ALTER COLUMN id SET DEFAULT nextval('public.role_modules_id_seq'::regclass);


--
-- TOC entry 7913 (class 2604 OID 17908)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 7948 (class 2604 OID 793731)
-- Name: site_transaction_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_transaction_metrics ALTER COLUMN id SET DEFAULT nextval('public.site_transaction_metrics_id_seq'::regclass);


--
-- TOC entry 7915 (class 2604 OID 17909)
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- TOC entry 7932 (class 2604 OID 208754)
-- Name: stripe_migration_error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_migration_error_logs ALTER COLUMN id SET DEFAULT nextval('public.stripe_migration_error_logs_id_seq'::regclass);


--
-- TOC entry 7929 (class 2604 OID 155367)
-- Name: trustpilot_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trustpilot_tokens ALTER COLUMN id SET DEFAULT nextval('public.trustpilot_tokens_id_seq'::regclass);


--
-- TOC entry 7920 (class 2604 OID 17910)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 7975 (class 2606 OID 17924)
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- TOC entry 8158 (class 2606 OID 906166)
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 8136 (class 2606 OID 234799)
-- Name: aws_server_logs aws_server_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_server_logs
    ADD CONSTRAINT aws_server_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 7978 (class 2606 OID 17928)
-- Name: billing_platforms billing_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_platforms
    ADD CONSTRAINT billing_platforms_pkey PRIMARY KEY (id);


--
-- TOC entry 8130 (class 2606 OID 155357)
-- Name: cancel_subscription_email_otps cancel_subscription_email_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cancel_subscription_email_otps
    ADD CONSTRAINT cancel_subscription_email_otps_pkey PRIMARY KEY (id);


--
-- TOC entry 7980 (class 2606 OID 17930)
-- Name: categories categories_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_key_key UNIQUE (key);


--
-- TOC entry 7983 (class 2606 OID 17932)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 7985 (class 2606 OID 17934)
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (code);


--
-- TOC entry 7987 (class 2606 OID 17936)
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (code);


--
-- TOC entry 7989 (class 2606 OID 17938)
-- Name: currency_rates currency_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currency_rates
    ADD CONSTRAINT currency_rates_pkey PRIMARY KEY (id);


--
-- TOC entry 7992 (class 2606 OID 17940)
-- Name: customer_quiz_result_details customer_quiz_result_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_details
    ADD CONSTRAINT customer_quiz_result_details_pkey PRIMARY KEY (id);


--
-- TOC entry 8138 (class 2606 OID 235040)
-- Name: customer_quiz_result_json_details customer_quiz_result_json_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_json_details
    ADD CONSTRAINT customer_quiz_result_json_details_pkey PRIMARY KEY (id);


--
-- TOC entry 8141 (class 2606 OID 409937)
-- Name: email_send_logs email_send_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_send_logs
    ADD CONSTRAINT email_send_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 8122 (class 2606 OID 18317)
-- Name: external_api_logs external_api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_api_logs
    ADD CONSTRAINT external_api_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 8146 (class 2606 OID 701742)
-- Name: failed_invoice_details failed_invoice_details_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_invoice_details
    ADD CONSTRAINT failed_invoice_details_invoice_id_key UNIQUE (invoice_id);


--
-- TOC entry 8148 (class 2606 OID 701740)
-- Name: failed_invoice_details failed_invoice_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_invoice_details
    ADD CONSTRAINT failed_invoice_details_pkey PRIMARY KEY (id);


--
-- TOC entry 8047 (class 2606 OID 17942)
-- Name: generic_settings generic_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.generic_settings
    ADD CONSTRAINT generic_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 8049 (class 2606 OID 17944)
-- Name: generic_settings generic_settings_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.generic_settings
    ADD CONSTRAINT generic_settings_site_id_key UNIQUE (site_id);


--
-- TOC entry 8052 (class 2606 OID 80220)
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (code);


--
-- TOC entry 8124 (class 2606 OID 94545)
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- TOC entry 8126 (class 2606 OID 94547)
-- Name: modules modules_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_slug_key UNIQUE (slug);


--
-- TOC entry 8056 (class 2606 OID 17948)
-- Name: payment_providers payment_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_providers
    ADD CONSTRAINT payment_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 8058 (class 2606 OID 17950)
-- Name: pricing_country_rules pricing_country_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 8062 (class 2606 OID 17952)
-- Name: pricing_master_rules pricing_master_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT pricing_master_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 8066 (class 2606 OID 17954)
-- Name: promocode_usage promocode_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocode_usage
    ADD CONSTRAINT promocode_usage_pkey PRIMARY KEY (id);


--
-- TOC entry 8072 (class 2606 OID 17956)
-- Name: promocodes promocodes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_code_key UNIQUE (code);


--
-- TOC entry 8076 (class 2606 OID 17958)
-- Name: promocodes promocodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_pkey PRIMARY KEY (id);


--
-- TOC entry 8079 (class 2606 OID 17960)
-- Name: question_options question_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_pkey PRIMARY KEY (id);


--
-- TOC entry 8081 (class 2606 OID 17962)
-- Name: question_orders question_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 8084 (class 2606 OID 17964)
-- Name: question_types question_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_types
    ADD CONSTRAINT question_types_name_key UNIQUE (name);


--
-- TOC entry 8086 (class 2606 OID 17966)
-- Name: question_types question_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_types
    ADD CONSTRAINT question_types_pkey PRIMARY KEY (id);


--
-- TOC entry 8089 (class 2606 OID 17968)
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- TOC entry 8091 (class 2606 OID 17970)
-- Name: quiz_public_cache quiz_public_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_public_cache
    ADD CONSTRAINT quiz_public_cache_pkey PRIMARY KEY (id);


--
-- TOC entry 8170 (class 2606 OID 1172374)
-- Name: quiz_question_report_data quiz_question_report_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_question_report_data
    ADD CONSTRAINT quiz_question_report_data_pkey PRIMARY KEY (id);


--
-- TOC entry 8168 (class 2606 OID 1172347)
-- Name: quiz_result_question_data quiz_result_question_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_result_question_data
    ADD CONSTRAINT quiz_result_question_data_pkey PRIMARY KEY (customer_quiz_result_id);


--
-- TOC entry 8032 (class 2606 OID 17972)
-- Name: customer_quiz_results quiz_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_results
    ADD CONSTRAINT quiz_results_pkey PRIMARY KEY (id);


--
-- TOC entry 8093 (class 2606 OID 17974)
-- Name: quizzes quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_pkey PRIMARY KEY (id);


--
-- TOC entry 8144 (class 2606 OID 469838)
-- Name: report_service_metrics report_service_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_service_metrics
    ADD CONSTRAINT report_service_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 8128 (class 2606 OID 94557)
-- Name: role_modules role_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_modules
    ADD CONSTRAINT role_modules_pkey PRIMARY KEY (id);


--
-- TOC entry 8096 (class 2606 OID 17976)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 8098 (class 2606 OID 17978)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 8156 (class 2606 OID 793748)
-- Name: site_transaction_metrics site_transaction_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_transaction_metrics
    ADD CONSTRAINT site_transaction_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 8104 (class 2606 OID 17980)
-- Name: sites sites_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_key_key UNIQUE (key);


--
-- TOC entry 8107 (class 2606 OID 17982)
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- TOC entry 8109 (class 2606 OID 17984)
-- Name: sites sites_secret_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_secret_key UNIQUE (secret);


--
-- TOC entry 8111 (class 2606 OID 62712)
-- Name: sites sites_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_slug_key UNIQUE (slug);


--
-- TOC entry 8134 (class 2606 OID 208765)
-- Name: stripe_migration_error_logs stripe_migration_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_migration_error_logs
    ADD CONSTRAINT stripe_migration_error_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 8114 (class 2606 OID 17986)
-- Name: token_blacklist token_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_blacklist
    ADD CONSTRAINT token_blacklist_pkey PRIMARY KEY (token);


--
-- TOC entry 8132 (class 2606 OID 155375)
-- Name: trustpilot_tokens trustpilot_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trustpilot_tokens
    ADD CONSTRAINT trustpilot_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 8060 (class 2606 OID 17988)
-- Name: pricing_country_rules uniq_pricing_country_rules_site_country; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT uniq_pricing_country_rules_site_country UNIQUE (site_id, country_code);


--
-- TOC entry 8064 (class 2606 OID 17990)
-- Name: pricing_master_rules uniq_pricing_master_rules_site_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT uniq_pricing_master_rules_site_id UNIQUE (site_id);


--
-- TOC entry 8043 (class 2606 OID 17992)
-- Name: customers unique_email_site_constraint; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT unique_email_site_constraint UNIQUE (email, site_id);


--
-- TOC entry 8118 (class 2606 OID 17994)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 8120 (class 2606 OID 17996)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 8045 (class 2606 OID 17998)
-- Name: customers users_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT users_pkey1 PRIMARY KEY (id);


--
-- TOC entry 7976 (class 1259 OID 17999)
-- Name: billing_platforms_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX billing_platforms_name ON public.billing_platforms USING btree (name);


--
-- TOC entry 7981 (class 1259 OID 18000)
-- Name: categories_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX categories_name ON public.categories USING btree (name);


--
-- TOC entry 8050 (class 1259 OID 18001)
-- Name: generic_settings_site_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX generic_settings_site_id_unique ON public.generic_settings USING btree (site_id);


--
-- TOC entry 8159 (class 1259 OID 906170)
-- Name: idx_activity_logs_channel_event_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_channel_event_created ON public.activity_logs USING btree (channel, event, created_at);


--
-- TOC entry 8160 (class 1259 OID 906172)
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_created_at ON public.activity_logs USING btree (created_at);


--
-- TOC entry 8161 (class 1259 OID 906168)
-- Name: idx_activity_logs_customer_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_customer_created ON public.activity_logs USING btree (customer_id, created_at);


--
-- TOC entry 8162 (class 1259 OID 906169)
-- Name: idx_activity_logs_quiz_result; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_quiz_result ON public.activity_logs USING btree (quiz_result_id);


--
-- TOC entry 8163 (class 1259 OID 906171)
-- Name: idx_activity_logs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_status_created ON public.activity_logs USING btree (status, created_at);


--
-- TOC entry 8164 (class 1259 OID 906167)
-- Name: idx_activity_logs_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_logs_trace_id ON public.activity_logs USING btree (trace_id);


--
-- TOC entry 8033 (class 1259 OID 314741)
-- Name: idx_billing_platform_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_platform_user_id ON public.customers USING btree (billing_platform_user_id);


--
-- TOC entry 8139 (class 1259 OID 314739)
-- Name: idx_cqrjd_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqrjd_quiz_result_id ON public.customer_quiz_result_json_details USING btree (customer_quiz_result_id);


--
-- TOC entry 7995 (class 1259 OID 526461)
-- Name: idx_cqrpt_amount_usd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqrpt_amount_usd ON public.customer_quiz_result_payment_transactions USING btree (amount_usd);


--
-- TOC entry 7996 (class 1259 OID 897657)
-- Name: idx_cqrpt_bin_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqrpt_bin_number ON public.customer_quiz_result_payment_transactions USING btree (bin_number);


--
-- TOC entry 7997 (class 1259 OID 896308)
-- Name: idx_cqrpt_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqrpt_invoice_id ON public.customer_quiz_result_payment_transactions USING btree (invoice_id);


--
-- TOC entry 7998 (class 1259 OID 496464)
-- Name: idx_cqrpt_refund_initiated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqrpt_refund_initiated_at ON public.customer_quiz_result_payment_transactions USING btree (refund_initiated_at);


--
-- TOC entry 7990 (class 1259 OID 45343)
-- Name: idx_currency_rates_code_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_currency_rates_code_date ON public.currency_rates USING btree (currency_code, updated_date);


--
-- TOC entry 7993 (class 1259 OID 314746)
-- Name: idx_customer_quiz_result_details_customer_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_result_details_customer_quiz_result_id ON public.customer_quiz_result_details USING btree (customer_quiz_result_id);


--
-- TOC entry 7994 (class 1259 OID 1183695)
-- Name: idx_customer_quiz_result_details_utm_sources_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_result_details_utm_sources_trgm ON public.customer_quiz_result_details USING gin (utm_sources public.gin_trgm_ops);


--
-- TOC entry 7999 (class 1259 OID 18003)
-- Name: idx_customer_quiz_result_payment_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_result_payment_transactions_status ON public.customer_quiz_result_payment_transactions USING btree (status);


--
-- TOC entry 8000 (class 1259 OID 18004)
-- Name: idx_customer_quiz_result_payment_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_result_payment_transactions_type ON public.customer_quiz_result_payment_transactions USING btree (type);


--
-- TOC entry 8023 (class 1259 OID 45526)
-- Name: idx_customer_quiz_results_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_results_created_at ON public.customer_quiz_results USING btree (created_at);


--
-- TOC entry 8024 (class 1259 OID 45527)
-- Name: idx_customer_quiz_results_customer_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_results_customer_created ON public.customer_quiz_results USING btree (customer_id, created_at);


--
-- TOC entry 8025 (class 1259 OID 18007)
-- Name: idx_customer_quiz_results_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_results_customer_id ON public.customer_quiz_results USING btree (customer_id);


--
-- TOC entry 8026 (class 1259 OID 18008)
-- Name: idx_customer_quiz_results_old_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_results_old_quiz_result_id ON public.customer_quiz_results USING btree (old_quiz_result_id);


--
-- TOC entry 8027 (class 1259 OID 314745)
-- Name: idx_customer_quiz_results_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_quiz_results_updated_at ON public.customer_quiz_results USING btree (updated_at);


--
-- TOC entry 8034 (class 1259 OID 18009)
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- TOC entry 8035 (class 1259 OID 18010)
-- Name: idx_customers_email_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_email_site_id ON public.customers USING btree (email, site_id);


--
-- TOC entry 8036 (class 1259 OID 18011)
-- Name: idx_customers_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_site_id ON public.customers USING btree (site_id);


--
-- TOC entry 8037 (class 1259 OID 45892)
-- Name: idx_customers_subscription_cancelled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_subscription_cancelled ON public.customers USING btree (subscription_cancelled_at);


--
-- TOC entry 8038 (class 1259 OID 1147339)
-- Name: idx_customers_subscription_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_subscription_created_at ON public.customers USING btree (subscription_created_at);


--
-- TOC entry 8039 (class 1259 OID 314738)
-- Name: idx_customers_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_subscription_status ON public.customers USING btree (subscription_status);


--
-- TOC entry 8040 (class 1259 OID 314744)
-- Name: idx_customers_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_updated_at ON public.customers USING btree (updated_at);


--
-- TOC entry 8149 (class 1259 OID 701743)
-- Name: idx_failed_invoice_details_quiz_data_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_invoice_details_quiz_data_id ON public.failed_invoice_details USING btree (quiz_data_id);


--
-- TOC entry 8054 (class 1259 OID 18013)
-- Name: idx_payment_providers_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_providers_name ON public.payment_providers USING btree (name);


--
-- TOC entry 8001 (class 1259 OID 18014)
-- Name: idx_payment_transactions_card_last_4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_card_last_4 ON public.customer_quiz_result_payment_transactions USING btree (card_last_4_digit);


--
-- TOC entry 8002 (class 1259 OID 18015)
-- Name: idx_payment_transactions_charge_card; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_charge_card ON public.customer_quiz_result_payment_transactions USING btree (charge_id, card_last_4_digit);


--
-- TOC entry 8003 (class 1259 OID 18016)
-- Name: idx_payment_transactions_charge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_charge_id ON public.customer_quiz_result_payment_transactions USING btree (charge_id);


--
-- TOC entry 8004 (class 1259 OID 45431)
-- Name: idx_payment_transactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_created_at ON public.customer_quiz_result_payment_transactions USING btree (created_at);


--
-- TOC entry 8005 (class 1259 OID 155339)
-- Name: idx_payment_transactions_paypal_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_paypal_email ON public.customer_quiz_result_payment_transactions USING btree (paypal_customer_email);


--
-- TOC entry 8006 (class 1259 OID 18018)
-- Name: idx_payment_transactions_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_quiz_result_id ON public.customer_quiz_result_payment_transactions USING btree (customer_quiz_result_id);


--
-- TOC entry 8007 (class 1259 OID 18019)
-- Name: idx_payment_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_transactions_status ON public.customer_quiz_result_payment_transactions USING btree (status);


--
-- TOC entry 8087 (class 1259 OID 45636)
-- Name: idx_questions_dashboard_count; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_questions_dashboard_count ON public.questions USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- TOC entry 8165 (class 1259 OID 1172349)
-- Name: idx_quiz_result_question_data_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quiz_result_question_data_created_at ON public.quiz_result_question_data USING btree (created_at);


--
-- TOC entry 8166 (class 1259 OID 1172348)
-- Name: idx_quiz_result_question_data_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quiz_result_question_data_status ON public.quiz_result_question_data USING btree (status);


--
-- TOC entry 8028 (class 1259 OID 18021)
-- Name: idx_quiz_results_country_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quiz_results_country_code ON public.customer_quiz_results USING btree (country_code);


--
-- TOC entry 8029 (class 1259 OID 18022)
-- Name: idx_quiz_results_country_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quiz_results_country_customer ON public.customer_quiz_results USING btree (country_code, customer_id);


--
-- TOC entry 8030 (class 1259 OID 18023)
-- Name: idx_quiz_results_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quiz_results_customer_id ON public.customer_quiz_results USING btree (customer_id);


--
-- TOC entry 8142 (class 1259 OID 469844)
-- Name: idx_report_service_metrics_site_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_report_service_metrics_site_date ON public.report_service_metrics USING btree (site_id, report_date);


--
-- TOC entry 8094 (class 1259 OID 18024)
-- Name: idx_roles_name_covering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_name_covering ON public.roles USING btree (name);


--
-- TOC entry 8150 (class 1259 OID 793755)
-- Name: idx_site_transaction_metrics_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_transaction_metrics_date ON public.site_transaction_metrics USING btree (date);


--
-- TOC entry 8151 (class 1259 OID 793756)
-- Name: idx_site_transaction_metrics_period_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_transaction_metrics_period_start ON public.site_transaction_metrics USING btree (period_start);


--
-- TOC entry 8152 (class 1259 OID 793757)
-- Name: idx_site_transaction_metrics_site_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_transaction_metrics_site_date ON public.site_transaction_metrics USING btree (site_id, date);


--
-- TOC entry 8153 (class 1259 OID 793754)
-- Name: idx_site_transaction_metrics_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_transaction_metrics_site_id ON public.site_transaction_metrics USING btree (site_id);


--
-- TOC entry 8154 (class 1259 OID 793758)
-- Name: idx_site_transaction_metrics_site_period; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_site_transaction_metrics_site_period ON public.site_transaction_metrics USING btree (site_id, period_start, period_end);


--
-- TOC entry 8099 (class 1259 OID 45704)
-- Name: idx_sites_dashboard_covering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_dashboard_covering ON public.sites USING btree (deleted_at, parent_id) WHERE (deleted_at IS NULL);


--
-- TOC entry 8100 (class 1259 OID 18026)
-- Name: idx_sites_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_parent_id ON public.sites USING btree (parent_id);


--
-- TOC entry 8041 (class 1259 OID 314743)
-- Name: idx_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_id ON public.customers USING btree (subscription_id);


--
-- TOC entry 8112 (class 1259 OID 45747)
-- Name: idx_token_blacklist_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_blacklist_expires_at ON public.token_blacklist USING btree (expires_at);


--
-- TOC entry 8008 (class 1259 OID 45432)
-- Name: idx_transactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_created_at ON public.customer_quiz_result_payment_transactions USING btree (created_at);


--
-- TOC entry 8009 (class 1259 OID 45433)
-- Name: idx_transactions_created_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_created_status ON public.customer_quiz_result_payment_transactions USING btree (created_at, status);


--
-- TOC entry 8010 (class 1259 OID 18030)
-- Name: idx_transactions_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_currency_code ON public.customer_quiz_result_payment_transactions USING btree (currency_code);


--
-- TOC entry 8011 (class 1259 OID 45434)
-- Name: idx_transactions_date_status_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_date_status_type ON public.customer_quiz_result_payment_transactions USING btree (created_at, status, type);


--
-- TOC entry 8012 (class 1259 OID 45491)
-- Name: idx_transactions_paid_ultra; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_paid_ultra ON public.customer_quiz_result_payment_transactions USING btree (customer_quiz_result_id, status, refunded_at) WHERE ((status = 'success'::public.enum_quiz_result_payment_transactions_status) AND (refunded_at IS NULL));


--
-- TOC entry 8013 (class 1259 OID 18033)
-- Name: idx_transactions_payment_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_payment_provider_id ON public.customer_quiz_result_payment_transactions USING btree (payment_provider_id);


--
-- TOC entry 8014 (class 1259 OID 45492)
-- Name: idx_transactions_refunded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_refunded_at ON public.customer_quiz_result_payment_transactions USING btree (refunded_at);


--
-- TOC entry 8015 (class 1259 OID 18035)
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status ON public.customer_quiz_result_payment_transactions USING btree (status);


--
-- TOC entry 8016 (class 1259 OID 45493)
-- Name: idx_transactions_status_refunded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status_refunded ON public.customer_quiz_result_payment_transactions USING btree (status, refunded_at);


--
-- TOC entry 8017 (class 1259 OID 45494)
-- Name: idx_transactions_subscription_distinct; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_subscription_distinct ON public.customer_quiz_result_payment_transactions USING btree (customer_quiz_result_id) WHERE ((type = 'subscription'::public.enum_quiz_result_payment_transactions_type) AND (refunded_at IS NULL));


--
-- TOC entry 8018 (class 1259 OID 45495)
-- Name: idx_transactions_subscription_ultra; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_subscription_ultra ON public.customer_quiz_result_payment_transactions USING btree (customer_quiz_result_id, type, refunded_at) WHERE ((type = 'subscription'::public.enum_quiz_result_payment_transactions_type) AND (refunded_at IS NULL));


--
-- TOC entry 8019 (class 1259 OID 45496)
-- Name: idx_transactions_success_distinct; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_success_distinct ON public.customer_quiz_result_payment_transactions USING btree (customer_quiz_result_id) WHERE ((status = 'success'::public.enum_quiz_result_payment_transactions_status) AND (refunded_at IS NULL));


--
-- TOC entry 8020 (class 1259 OID 18040)
-- Name: idx_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_type ON public.customer_quiz_result_payment_transactions USING btree (type);


--
-- TOC entry 8021 (class 1259 OID 45497)
-- Name: idx_transactions_type_refunded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_type_refunded ON public.customer_quiz_result_payment_transactions USING btree (type, refunded_at);


--
-- TOC entry 8022 (class 1259 OID 314740)
-- Name: idx_transactions_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_updated_at ON public.customer_quiz_result_payment_transactions USING btree (updated_at);


--
-- TOC entry 8115 (class 1259 OID 45799)
-- Name: idx_users_dashboard_covering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_dashboard_covering ON public.users USING btree (role_id, status, deleted_at) WHERE ((status = 'active'::public.enum_users_status) AND (deleted_at IS NULL));


--
-- TOC entry 8116 (class 1259 OID 18043)
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- TOC entry 8067 (class 1259 OID 18044)
-- Name: promocode_usage_promocode_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocode_usage_promocode_id ON public.promocode_usage USING btree (promocode_id);


--
-- TOC entry 8068 (class 1259 OID 18045)
-- Name: promocode_usage_promocode_id_used_for_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocode_usage_promocode_id_used_for_quiz_result_id ON public.promocode_usage USING btree (promocode_id, used_for_quiz_result_id);


--
-- TOC entry 8069 (class 1259 OID 18046)
-- Name: promocode_usage_used_for_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocode_usage_used_for_quiz_result_id ON public.promocode_usage USING btree (used_for_quiz_result_id);


--
-- TOC entry 8070 (class 1259 OID 18047)
-- Name: promocodes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocodes_code ON public.promocodes USING btree (code);


--
-- TOC entry 8073 (class 1259 OID 18048)
-- Name: promocodes_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocodes_domain ON public.promocodes USING btree (domain);


--
-- TOC entry 8074 (class 1259 OID 18049)
-- Name: promocodes_generated_from_quiz_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocodes_generated_from_quiz_result_id ON public.promocodes USING btree (generated_from_quiz_result_id);


--
-- TOC entry 8077 (class 1259 OID 18050)
-- Name: promocodes_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promocodes_site_id ON public.promocodes USING btree (site_id);


--
-- TOC entry 8082 (class 1259 OID 18051)
-- Name: question_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX question_types_name ON public.question_types USING btree (name);


--
-- TOC entry 8101 (class 1259 OID 18052)
-- Name: sites_billing_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sites_billing_platform_id ON public.sites USING btree (billing_platform_id);


--
-- TOC entry 8102 (class 1259 OID 18053)
-- Name: sites_host; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sites_host ON public.sites USING btree (host);


--
-- TOC entry 8105 (class 1259 OID 18054)
-- Name: sites_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sites_name ON public.sites USING btree (name);


--
-- TOC entry 8053 (class 1259 OID 80221)
-- Name: uniq_languages_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_languages_code ON public.languages USING btree (code);


--
-- TOC entry 8221 (class 2606 OID 155358)
-- Name: cancel_subscription_email_otps cancel_subscription_email_otps_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cancel_subscription_email_otps
    ADD CONSTRAINT cancel_subscription_email_otps_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE RESTRICT;


--
-- TOC entry 8171 (class 2606 OID 18056)
-- Name: customer_quiz_result_details customer_quiz_result_details_best_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_details
    ADD CONSTRAINT customer_quiz_result_details_best_category_id_fkey FOREIGN KEY (best_category_id) REFERENCES public.categories(id) ON DELETE RESTRICT;


--
-- TOC entry 8172 (class 2606 OID 18061)
-- Name: customer_quiz_result_details customer_quiz_result_details_customer_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_details
    ADD CONSTRAINT customer_quiz_result_details_customer_quiz_result_id_fkey FOREIGN KEY (customer_quiz_result_id) REFERENCES public.customer_quiz_results(id);


--
-- TOC entry 8222 (class 2606 OID 235041)
-- Name: customer_quiz_result_json_details customer_quiz_result_json_details_customer_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_json_details
    ADD CONSTRAINT customer_quiz_result_json_details_customer_quiz_result_id_fkey FOREIGN KEY (customer_quiz_result_id) REFERENCES public.customer_quiz_results(id);


--
-- TOC entry 8173 (class 2606 OID 18066)
-- Name: customer_quiz_result_payment_transactions customer_quiz_result_payment_transactions_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_payment_transactions
    ADD CONSTRAINT customer_quiz_result_payment_transactions_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.currencies(code) ON DELETE RESTRICT;


--
-- TOC entry 8174 (class 2606 OID 18071)
-- Name: customer_quiz_result_payment_transactions customer_quiz_result_payment_transactions_customer_quiz_result_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_payment_transactions
    ADD CONSTRAINT customer_quiz_result_payment_transactions_customer_quiz_result_ FOREIGN KEY (customer_quiz_result_id) REFERENCES public.customer_quiz_results(id) ON DELETE RESTRICT;


--
-- TOC entry 8176 (class 2606 OID 18076)
-- Name: customer_quiz_results customer_quiz_results_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_results
    ADD CONSTRAINT customer_quiz_results_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.countries(code) ON DELETE RESTRICT;


--
-- TOC entry 8177 (class 2606 OID 18081)
-- Name: customer_quiz_results customer_quiz_results_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_results
    ADD CONSTRAINT customer_quiz_results_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE RESTRICT;


--
-- TOC entry 8178 (class 2606 OID 18086)
-- Name: customer_quiz_results customer_quiz_results_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_results
    ADD CONSTRAINT customer_quiz_results_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE RESTRICT;


--
-- TOC entry 8223 (class 2606 OID 409938)
-- Name: email_send_logs email_send_logs_customer_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_send_logs
    ADD CONSTRAINT email_send_logs_customer_quiz_result_id_fkey FOREIGN KEY (customer_quiz_result_id) REFERENCES public.customer_quiz_results(id);


--
-- TOC entry 8180 (class 2606 OID 18091)
-- Name: generic_settings generic_settings_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.generic_settings
    ADD CONSTRAINT generic_settings_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8181 (class 2606 OID 18096)
-- Name: payment_providers payment_providers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_providers
    ADD CONSTRAINT payment_providers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8182 (class 2606 OID 18101)
-- Name: payment_providers payment_providers_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_providers
    ADD CONSTRAINT payment_providers_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8183 (class 2606 OID 18106)
-- Name: pricing_country_rules pricing_country_rules_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.countries(code) ON DELETE RESTRICT;


--
-- TOC entry 8184 (class 2606 OID 18111)
-- Name: pricing_country_rules pricing_country_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8185 (class 2606 OID 18116)
-- Name: pricing_country_rules pricing_country_rules_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.currencies(code) ON DELETE RESTRICT;


--
-- TOC entry 8186 (class 2606 OID 18121)
-- Name: pricing_country_rules pricing_country_rules_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8187 (class 2606 OID 18126)
-- Name: pricing_country_rules pricing_country_rules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_country_rules
    ADD CONSTRAINT pricing_country_rules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8188 (class 2606 OID 18131)
-- Name: pricing_master_rules pricing_master_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT pricing_master_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8189 (class 2606 OID 18136)
-- Name: pricing_master_rules pricing_master_rules_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT pricing_master_rules_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.currencies(code) ON DELETE RESTRICT;


--
-- TOC entry 8190 (class 2606 OID 18141)
-- Name: pricing_master_rules pricing_master_rules_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT pricing_master_rules_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8191 (class 2606 OID 18146)
-- Name: pricing_master_rules pricing_master_rules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_master_rules
    ADD CONSTRAINT pricing_master_rules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8192 (class 2606 OID 18151)
-- Name: promocode_usage promocode_usage_promocode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocode_usage
    ADD CONSTRAINT promocode_usage_promocode_id_fkey FOREIGN KEY (promocode_id) REFERENCES public.promocodes(id) ON DELETE CASCADE;


--
-- TOC entry 8193 (class 2606 OID 18156)
-- Name: promocode_usage promocode_usage_used_for_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocode_usage
    ADD CONSTRAINT promocode_usage_used_for_quiz_result_id_fkey FOREIGN KEY (used_for_quiz_result_id) REFERENCES public.customer_quiz_results(id) ON DELETE RESTRICT;


--
-- TOC entry 8194 (class 2606 OID 18161)
-- Name: promocodes promocodes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 8195 (class 2606 OID 18166)
-- Name: promocodes promocodes_generated_from_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_generated_from_quiz_result_id_fkey FOREIGN KEY (generated_from_quiz_result_id) REFERENCES public.customer_quiz_results(id) ON DELETE RESTRICT;


--
-- TOC entry 8196 (class 2606 OID 18171)
-- Name: promocodes promocodes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8197 (class 2606 OID 18176)
-- Name: question_options question_options_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- TOC entry 8198 (class 2606 OID 18181)
-- Name: question_orders question_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8199 (class 2606 OID 18186)
-- Name: question_orders question_orders_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE SET NULL;


--
-- TOC entry 8200 (class 2606 OID 18191)
-- Name: question_orders question_orders_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE SET NULL;


--
-- TOC entry 8201 (class 2606 OID 18196)
-- Name: question_orders question_orders_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- TOC entry 8202 (class 2606 OID 18201)
-- Name: question_orders question_orders_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.question_orders
    ADD CONSTRAINT question_orders_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8203 (class 2606 OID 18206)
-- Name: questions questions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE RESTRICT;


--
-- TOC entry 8204 (class 2606 OID 18211)
-- Name: questions questions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8205 (class 2606 OID 18216)
-- Name: questions questions_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.questions(id) ON DELETE RESTRICT;


--
-- TOC entry 8206 (class 2606 OID 18221)
-- Name: questions questions_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE RESTRICT;


--
-- TOC entry 8207 (class 2606 OID 18226)
-- Name: questions questions_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8208 (class 2606 OID 18231)
-- Name: questions questions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8209 (class 2606 OID 18236)
-- Name: quiz_public_cache quiz_public_cache_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_public_cache
    ADD CONSTRAINT quiz_public_cache_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE CASCADE;


--
-- TOC entry 8210 (class 2606 OID 18241)
-- Name: quiz_public_cache quiz_public_cache_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quiz_public_cache
    ADD CONSTRAINT quiz_public_cache_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- TOC entry 8175 (class 2606 OID 18246)
-- Name: customer_quiz_result_payment_transactions quiz_result_payment_transactions_quiz_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_quiz_result_payment_transactions
    ADD CONSTRAINT quiz_result_payment_transactions_quiz_result_id_fkey FOREIGN KEY (customer_quiz_result_id) REFERENCES public.customer_quiz_results(id) ON DELETE RESTRICT;


--
-- TOC entry 8211 (class 2606 OID 18251)
-- Name: quizzes quizzes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8212 (class 2606 OID 18256)
-- Name: quizzes quizzes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8213 (class 2606 OID 18261)
-- Name: quizzes quizzes_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 8224 (class 2606 OID 469839)
-- Name: report_service_metrics report_service_metrics_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_service_metrics
    ADD CONSTRAINT report_service_metrics_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id);


--
-- TOC entry 8219 (class 2606 OID 94563)
-- Name: role_modules role_modules_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_modules
    ADD CONSTRAINT role_modules_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.modules(id);


--
-- TOC entry 8220 (class 2606 OID 94558)
-- Name: role_modules role_modules_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_modules
    ADD CONSTRAINT role_modules_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- TOC entry 8225 (class 2606 OID 793749)
-- Name: site_transaction_metrics site_transaction_metrics_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_transaction_metrics
    ADD CONSTRAINT site_transaction_metrics_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 8214 (class 2606 OID 18266)
-- Name: sites sites_billing_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_billing_platform_id_fkey FOREIGN KEY (billing_platform_id) REFERENCES public.billing_platforms(id) ON DELETE RESTRICT;


--
-- TOC entry 8215 (class 2606 OID 18271)
-- Name: sites sites_billing_platform_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_billing_platform_id_fkey1 FOREIGN KEY (billing_platform_id) REFERENCES public.billing_platforms(id) ON DELETE RESTRICT;


--
-- TOC entry 8216 (class 2606 OID 80233)
-- Name: sites sites_language_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_language_code_fkey FOREIGN KEY (language_code) REFERENCES public.languages(code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 8217 (class 2606 OID 18281)
-- Name: sites sites_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


--
-- TOC entry 8218 (class 2606 OID 18286)
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- TOC entry 8179 (class 2606 OID 18291)
-- Name: customers users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE RESTRICT;


-- Completed on 2026-08-17 13:21:41

--
-- PostgreSQL database dump complete
--

\unrestrict WgWELJsiem2png8vYS2U259pFHZzE3EFWa71mmPidGdqzfZQiCE2pRehHrBXZdZ

